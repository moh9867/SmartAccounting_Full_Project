using System.Drawing;
using System.Drawing.Imaging;
using Microsoft.Extensions.Logging;

namespace SmartAccountingAgent.Services.Invoice
{
    // ===================================================
    // معالج الصور قبل OCR
    // يحسن جودة الصورة لرفع دقة Tesseract
    // خفيف جداً — يستخدم System.Drawing فقط
    // ===================================================
    public class ImagePreprocessor
    {
        private readonly ILogger<ImagePreprocessor> _logger;

        public ImagePreprocessor(ILogger<ImagePreprocessor> logger) => _logger = logger;

        public byte[] Preprocess(byte[] inputBytes)
        {
            try
            {
                using var ms     = new MemoryStream(inputBytes);
                using var bitmap = new Bitmap(ms);

                // 1. تدوير إن كانت الصورة مائلة
                var deskewed = Deskew(bitmap);

                // 2. تحويل لأبيض وأسود مع تعزيز التباين
                var binarized = Binarize(deskewed);

                // 3. تكبير إن كانت صغيرة جداً
                var resized = EnsureMinResolution(binarized, minWidth: 1000);

                // 4. تحويل للـ PNG للحفاظ على الجودة
                using var output = new MemoryStream();
                resized.Save(output, ImageFormat.Png);
                return output.ToArray();
            }
            catch (Exception ex)
            {
                _logger.LogWarning("⚠️ فشل معالجة الصورة: {Msg} — سيتم استخدام الصورة الأصلية", ex.Message);
                return inputBytes;
            }
        }

        // ===================================================
        // تصحيح ميل الصورة (Deskewing)
        // ===================================================
        private Bitmap Deskew(Bitmap src)
        {
            try
            {
                var angle = DetectSkewAngle(src);
                if (Math.Abs(angle) < 0.5) return src; // لا داعي للتدوير

                _logger.LogInformation("↻ تصحيح ميل الصورة: {Angle:F1}°", angle);
                return RotateBitmap(src, -angle);
            }
            catch
            {
                return src;
            }
        }

        private double DetectSkewAngle(Bitmap bmp)
        {
            // خوارزمية بسيطة: تحليل توزيع البكسل الأفقي
            using var gray = ToGrayscale(bmp);
            int width  = gray.Width;
            int height = gray.Height;

            var angles      = new List<double>();
            var sampleLines = Math.Min(height, 30);

            for (int row = height / 4; row < 3 * height / 4; row += height / sampleLines)
            {
                int firstDark = -1, lastDark = -1;
                for (int col = 0; col < width; col++)
                {
                    var pixel = gray.GetPixel(col, row);
                    if (pixel.GetBrightness() < 0.5f)
                    {
                        if (firstDark < 0) firstDark = col;
                        lastDark = col;
                    }
                }
                if (firstDark >= 0 && lastDark > firstDark)
                    angles.Add(Math.Atan2(0, lastDark - firstDark) * 180 / Math.PI);
            }

            return angles.Any() ? angles.Average() : 0;
        }

        private Bitmap RotateBitmap(Bitmap src, double angleDeg)
        {
            var radians = angleDeg * Math.PI / 180;
            var cos     = Math.Abs(Math.Cos(radians));
            var sin     = Math.Abs(Math.Sin(radians));
            var newW    = (int)(src.Width * cos + src.Height * sin);
            var newH    = (int)(src.Width * sin + src.Height * cos);

            var result = new Bitmap(newW, newH);
            result.SetResolution(src.HorizontalResolution, src.VerticalResolution);

            using var g = Graphics.FromImage(result);
            g.Clear(Color.White);
            g.TranslateTransform(newW / 2f, newH / 2f);
            g.RotateTransform((float)angleDeg);
            g.TranslateTransform(-src.Width / 2f, -src.Height / 2f);
            g.DrawImage(src, 0, 0);

            return result;
        }

        // ===================================================
        // تحويل للأبيض والأسود (Binarization)
        // خوارزمية Otsu المبسطة
        // ===================================================
        private Bitmap Binarize(Bitmap src)
        {
            var gray      = ToGrayscale(src);
            var threshold = OtsuThreshold(gray);
            var result    = new Bitmap(gray.Width, gray.Height, PixelFormat.Format32bppArgb);

            for (int y = 0; y < gray.Height; y++)
            for (int x = 0; x < gray.Width;  x++)
            {
                var brightness = gray.GetPixel(x, y).GetBrightness();
                result.SetPixel(x, y, brightness > threshold ? Color.White : Color.Black);
            }

            return result;
        }

        private Bitmap ToGrayscale(Bitmap src)
        {
            var gray = new Bitmap(src.Width, src.Height, PixelFormat.Format32bppArgb);
            using var g = Graphics.FromImage(gray);

            var cm = new ColorMatrix(new float[][]
            {
                new float[] { 0.299f, 0.299f, 0.299f, 0, 0 },
                new float[] { 0.587f, 0.587f, 0.587f, 0, 0 },
                new float[] { 0.114f, 0.114f, 0.114f, 0, 0 },
                new float[] { 0,      0,      0,      1, 0 },
                new float[] { 0,      0,      0,      0, 1 }
            });

            var attrs = new ImageAttributes();
            attrs.SetColorMatrix(cm);
            g.DrawImage(src, new Rectangle(0, 0, src.Width, src.Height),
                0, 0, src.Width, src.Height, GraphicsUnit.Pixel, attrs);

            return gray;
        }

        private float OtsuThreshold(Bitmap gray)
        {
            var histogram = new int[256];
            for (int y = 0; y < gray.Height; y++)
            for (int x = 0; x < gray.Width;  x++)
                histogram[(int)(gray.GetPixel(x, y).GetBrightness() * 255)]++;

            int total     = gray.Width * gray.Height;
            float sum     = histogram.Select((v, i) => (float)(v * i)).Sum();
            float sumB    = 0, wB = 0;
            float maxVar  = 0, threshold = 0.5f;

            for (int t = 0; t < 256; t++)
            {
                wB += histogram[t];
                if (wB == 0) continue;
                float wF = total - wB;
                if (wF == 0) break;

                sumB += t * histogram[t];
                float mB  = sumB / wB;
                float mF  = (sum - sumB) / wF;
                float var  = wB * wF * (mB - mF) * (mB - mF);

                if (var > maxVar) { maxVar = var; threshold = t / 255f; }
            }

            return threshold;
        }

        // ===================================================
        // ضمان حد أدنى للدقة
        // ===================================================
        private Bitmap EnsureMinResolution(Bitmap src, int minWidth)
        {
            if (src.Width >= minWidth) return src;

            var scale  = (float)minWidth / src.Width;
            var newW   = minWidth;
            var newH   = (int)(src.Height * scale);
            var result = new Bitmap(newW, newH);

            using var g = Graphics.FromImage(result);
            g.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            g.DrawImage(src, 0, 0, newW, newH);

            _logger.LogInformation("↑ تكبير الصورة: {W}→{NW}px", src.Width, newW);
            return result;
        }
    }
}
