using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SmartAccountingAgent.Models;

namespace SmartAccountingAgent.Services.Invoice
{
    public class InvoiceParserService : IDisposable
    {
        private readonly ILogger<InvoiceParserService> _logger;
        private readonly InvoiceParserOptions          _opts;
        private readonly HttpClient                    _http;
        private dynamic? _tesseract;
        private bool     _tesseractReady = false;

        public InvoiceParserService(
            IOptions<InvoiceParserOptions> opts,
            ILogger<InvoiceParserService>  logger,
            IHttpClientFactory             httpFactory)
        {
            _opts   = opts.Value;
            _logger = logger;
            _http   = httpFactory.CreateClient("AzureVision");
            InitTesseract();
        }

        public async Task<ParsedInvoice?> ParseFromBase64Async(string imageBase64)
        {
            try
            {
                var b64 = imageBase64.Contains(',') ? imageBase64.Split(',')[1] : imageBase64;
                return await ParseFromBytesAsync(Convert.FromBase64String(b64));
            }
            catch (Exception ex) { _logger.LogError(ex, "خطأ في فك تشفير الصورة"); return null; }
        }

        public async Task<ParsedInvoice?> ParseFromBytesAsync(byte[] imageBytes)
        {
            string rawText   = string.Empty;
            float  confidence = 0f;

            // أولاً: Tesseract محلي
            if (_tesseractReady)
            {
                try
                {
                    _logger.LogInformation("OCR: Tesseract يعمل...");
                    (rawText, confidence) = RunTesseract(imageBytes);
                    if (confidence < _opts.MinTesseractConfidence)
                    { _logger.LogWarning("Tesseract: ثقة منخفضة {C:P0}", confidence); rawText = ""; }
                    else _logger.LogInformation("Tesseract: ثقة={C:P0} | {N} حرف", confidence, rawText.Length);
                }
                catch (Exception ex) { _logger.LogWarning(ex, "Tesseract فشل"); rawText = ""; }
            }

            // ثانياً: Azure Vision كاحتياط
            if (string.IsNullOrWhiteSpace(rawText) && !string.IsNullOrEmpty(_opts.AzureEndpoint))
            {
                try
                {
                    _logger.LogInformation("OCR: Azure Vision يعمل...");
                    (rawText, confidence) = await RunAzureAsync(imageBytes);
                    _logger.LogInformation("Azure: {N} حرف | ثقة={C:P0}", rawText.Length, confidence);
                }
                catch (Exception ex) { _logger.LogError(ex, "Azure Vision فشل"); }
            }

            if (string.IsNullOrWhiteSpace(rawText)) return null;

            var parsed        = ExtractInvoiceData(rawText);
            parsed.Confidence = confidence;
            parsed.RawText    = rawText;
            return parsed;
        }

        private (string text, float confidence) RunTesseract(byte[] imageBytes)
        {
            var tessType   = Type.GetType("Tesseract.TesseractEngine, Tesseract")!;
            var pixType    = Type.GetType("Tesseract.Pix, Tesseract")!;
            var dataPath   = _opts.TesseractDataPath
                          ?? Path.Combine(AppContext.BaseDirectory, "tessdata");
            var langs      = _opts.Languages ?? "ara+eng";

            using var engine = (IDisposable)Activator.CreateInstance(tessType, dataPath, langs, 3)!;
            var loadMethod   = pixType.GetMethod("LoadFromMemory", new[] { typeof(byte[]) })!;
            using var pix    = (IDisposable)loadMethod.Invoke(null, new object[] { imageBytes })!;

            var processMethod = engine.GetType().GetMethod("Process", new[] { pix.GetType() })!;
            using var page    = (IDisposable)processMethod.Invoke(engine, new[] { pix })!;

            var getText = page.GetType().GetMethod("GetText")!;
            var getConf = page.GetType().GetMethod("GetMeanConfidence")!;

            var text = getText.Invoke(page, null) as string ?? "";
            var conf = (float)(getConf.Invoke(page, null) ?? 0f);
            return (text.Trim(), conf);
        }

        private void InitTesseract()
        {
            try
            {
                var tessType = Type.GetType("Tesseract.TesseractEngine, Tesseract");
                if (tessType == null) { _logger.LogWarning("Tesseract غير مثبّت"); return; }

                var dataPath = _opts.TesseractDataPath
                            ?? Path.Combine(AppContext.BaseDirectory, "tessdata");
                if (!Directory.Exists(dataPath))
                { _logger.LogWarning("tessdata مفقود في: {P}", dataPath); return; }

                _tesseractReady = true;
                _logger.LogInformation("Tesseract جاهز | {L}", _opts.Languages);
            }
            catch (Exception ex) { _logger.LogWarning(ex, "فشل تهيئة Tesseract"); }
        }

        private async Task<(string text, float confidence)> RunAzureAsync(byte[] imageBytes)
        {
            var endpoint = _opts.AzureEndpoint!.TrimEnd('/');
            var readUrl  = $"{endpoint}/vision/v3.2/read/analyze?language=ar";

            _http.DefaultRequestHeaders.Remove("Ocp-Apim-Subscription-Key");
            _http.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", _opts.AzureKey);

            using var content = new ByteArrayContent(imageBytes);
            content.Headers.ContentType =
                new System.Net.Http.Headers.MediaTypeHeaderValue("application/octet-stream");

            var post = await _http.PostAsync(readUrl, content);
            post.EnsureSuccessStatusCode();

            var opUrl = post.Headers.GetValues("Operation-Location").First();

            for (int i = 0; i < 15; i++)
            {
                await Task.Delay(1200);
                var get     = await _http.GetStringAsync(opUrl);
                var result  = JsonSerializer.Deserialize<AzureReadResult>(get,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                if (result?.Status == "succeeded")
                {
                    var sb = new StringBuilder();
                    float totalConf = 0; int wc = 0;
                    foreach (var pg in result.AnalyzeResult?.ReadResults ?? new())
                    foreach (var ln in pg.Lines ?? new())
                    {
                        sb.AppendLine(ln.Text);
                        foreach (var w in ln.Words ?? new()) { totalConf += w.Confidence; wc++; }
                    }
                    return (sb.ToString().Trim(), wc > 0 ? totalConf / wc : 0f);
                }
                if (result?.Status == "failed") throw new Exception("Azure Vision فشل");
            }
            throw new TimeoutException("Azure Vision: انتهى الوقت");
        }

        // ===================================================
        // محلل النصوص — يستخرج بيانات الفاتورة من النص الخام
        // ===================================================
        private ParsedInvoice ExtractInvoiceData(string text)
        {
            var lines   = text.Split('\n', StringSplitOptions.RemoveEmptyEntries)
                              .Select(l => l.Trim()).Where(l => l.Length > 1).ToList();
            var invoice = new ParsedInvoice { RawText = text };

            invoice.SupplierName  = ExtractSupplier(lines, text);
            invoice.InvoiceNumber = ExtractPattern(text,
                @"(?:رقم الفاتورة|فاتورة رقم|Invoice No\.?|Inv#?)[:\s#]*([A-Za-z0-9\-\/]{2,20})");
            invoice.Date          = ExtractDate(text);
            invoice.Lines         = ExtractLines(lines);
            invoice.TotalAmount   = ExtractAmount(text,
                new[]{"الإجمالي الكلي","إجمالي","المجموع","Grand Total","Total"}, invoice.Lines);
            invoice.TaxAmount     = ExtractAmount(text,
                new[]{"ضريبة القيمة المضافة","ض.ق.م","VAT","Tax"}, null);

            return invoice;
        }

        private string? ExtractSupplier(List<string> lines, string text)
        {
            foreach (var pat in new[]{
                @"(?:المورد|شركة|مؤسسة|محل|صادر عن)[:\s]+([^\n\d،,]{3,50})",
                @"(?:Supplier|Company|From|Vendor)[:\s]+([^\n\d]{3,50})" })
            {
                var m = Regex.Match(text, pat, RegexOptions.IgnoreCase);
                if (m.Success) return m.Groups[1].Value.Trim();
            }
            return lines.FirstOrDefault(l =>
                l.Length > 4 && l.Length < 60 &&
                !Regex.IsMatch(l, @"^\d") &&
                !IsKeywordLine(l))?.Trim();
        }

        private string? ExtractPattern(string text, string pattern)
        {
            var m = Regex.Match(text, pattern, RegexOptions.IgnoreCase);
            return m.Success ? m.Groups[1].Value.Trim() : null;
        }

        private DateTime? ExtractDate(string text)
        {
            var ctx = Regex.Match(text,
                @"(?:تاريخ|Date|التاريخ)[:\s]*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})",
                RegexOptions.IgnoreCase);
            if (ctx.Success && TryParseDate(ctx.Groups[1].Value, out var d1)) return d1;

            var m = Regex.Match(text, @"(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{2,4})");
            if (m.Success) {
                int day = int.Parse(m.Groups[1].Value),
                    mon = int.Parse(m.Groups[2].Value),
                    yr  = int.Parse(m.Groups[3].Value);
                if (yr < 100) yr += 2000;
                try { return new DateTime(yr, mon, day); } catch { }
            }
            return null;
        }

        private bool TryParseDate(string s, out DateTime dt) => DateTime.TryParse(s, out dt);

        private List<InvoiceLineDto> ExtractLines(List<string> lines)
        {
            var result = new List<InvoiceLineDto>();
            var pat = new Regex(
                @"^(.{2,35}?)\s{1,10}(\d+(?:[,\.]\d+)?)\s+(\d+(?:[,\.]\d+)?)\s+(\d+(?:[,\.]\d+)?)?\s*$");
            var simple = new Regex(@"^(.{3,35}?)\s{2,}(\d+(?:[,\.]\d+)?)$");

            foreach (var line in lines)
            {
                if (IsKeywordLine(line) || line.Length < 5) continue;

                var m1 = pat.Match(line);
                if (m1.Success
                    && decimal.TryParse(Norm(m1.Groups[2].Value), out var qty)
                    && decimal.TryParse(Norm(m1.Groups[3].Value), out var price)
                    && qty > 0 && price > 0 && price < 1_000_000)
                {
                    result.Add(new InvoiceLineDto
                    {
                        ProductName = m1.Groups[1].Value.Trim(),
                        Quantity    = qty,
                        UnitPrice   = price
                    });
                    continue;
                }

                var m2 = simple.Match(line);
                if (m2.Success
                    && decimal.TryParse(Norm(m2.Groups[2].Value), out var amt)
                    && amt > 0 && amt < 1_000_000)
                {
                    result.Add(new InvoiceLineDto
                    {
                        ProductName = m2.Groups[1].Value.Trim(),
                        Quantity    = 1,
                        UnitPrice   = amt
                    });
                }
            }
            return result;
        }

        private decimal? ExtractAmount(string text, string[] keywords, List<InvoiceLineDto>? fallbackLines)
        {
            foreach (var kw in keywords)
            {
                var m = Regex.Match(text,
                    Regex.Escape(kw) + @"[:\s]*([0-9,\.]+)",
                    RegexOptions.IgnoreCase | RegexOptions.RightToLeft);
                if (m.Success && decimal.TryParse(Norm(m.Groups[1].Value), out var v) && v > 0)
                    return v;
            }
            return fallbackLines?.Any() == true ? fallbackLines.Sum(l => l.LineTotal) : null;
        }

        private static bool IsKeywordLine(string l)
        {
            var kws = new[]{"إجمالي","مجموع","total","ضريبة","vat","خصم","discount",
                            "رقم","invoice","تاريخ","date","المورد","supplier","شكراً","thank"};
            var low = l.ToLower();
            return kws.Any(k => low.Contains(k));
        }

        private static string Norm(string s) => s.Replace(",", "").Replace("٫", ".").Trim();

        public void Dispose() => _http?.Dispose();
    }

    public class InvoiceParserOptions
    {
        public string? TesseractDataPath       { get; set; }
        public string  Languages               { get; set; } = "ara+eng";
        public string? AzureEndpoint           { get; set; }
        public string? AzureKey                { get; set; }
        public float   MinTesseractConfidence  { get; set; } = 0.45f;
    }

    internal class AzureReadResult
    {
        public string?             Status        { get; set; }
        public AzureAnalyzeResult? AnalyzeResult { get; set; }
    }
    internal class AzureAnalyzeResult { public List<AzureReadPage>?  ReadResults { get; set; } }
    internal class AzureReadPage      { public List<AzureReadLine>?  Lines       { get; set; } }
    internal class AzureReadLine      { public string?               Text        { get; set; }
                                        public List<AzureReadWord>?  Words       { get; set; } }
    internal class AzureReadWord      { public string?               Text        { get; set; }
                                        public float                 Confidence  { get; set; } }
}
