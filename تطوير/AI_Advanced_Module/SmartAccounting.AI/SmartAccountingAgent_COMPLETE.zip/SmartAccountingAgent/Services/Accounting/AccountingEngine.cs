using Microsoft.EntityFrameworkCore;
using SmartAccountingAgent.Models;

namespace SmartAccountingAgent.Services.Accounting
{
    // ===================================================
    // محرك المحاسبة الكامل
    // يتعامل مع: الفواتير، القيود، الحسابات، التسويات
    // ===================================================
    public class AccountingEngine
    {
        private readonly IAccountingDb _db;

        // كودات الحسابات الأساسية (خطة الحسابات)
        private const string CASH          = "1010"; // النقدية
        private const string BANK          = "1020"; // البنك
        private const string RECEIVABLES   = "1110"; // ذمم مدينة (عملاء)
        private const string INVENTORY     = "1210"; // المخزون
        private const string PAYABLES      = "2110"; // ذمم دائنة (موردين)
        private const string SALES_REV     = "4010"; // إيرادات المبيعات
        private const string SALES_DISC    = "4020"; // خصم المبيعات
        private const string COGS          = "5010"; // تكلفة البضاعة المباعة
        private const string PURCHASE_EXP  = "5110"; // مشتريات
        private const string TAX_PAYABLE   = "2210"; // ضريبة القيمة المضافة

        public AccountingEngine(IAccountingDb db) => _db = db;

        // ===================================================
        // تسجيل فاتورة مبيعات مع القيود المحاسبية الكاملة
        // ===================================================
        public async Task<InvoiceResult> PostSalesInvoiceAsync(CreateInvoiceRequest req)
        {
            ValidateInvoice(req);

            // توليد رقم الفاتورة
            var number = await GenerateInvoiceNumber("INV");

            // حساب المبالغ
            var subtotal  = req.Subtotal;
            var discAmt   = req.DiscountAmount;
            var taxAmt    = req.TaxAmount;
            var total     = req.Total;
            var remaining = req.Remaining;

            // ===== القيود المحاسبية =====
            var journal = new List<JournalLine>();

            if (req.Payment == PaymentMethod.Cash)
            {
                // نقدي: من ح/ النقدية
                journal.Add(new JournalLine
                {
                    AccountCode = CASH,
                    AccountName = "النقدية",
                    Debit       = total,
                    Note        = $"تحصيل فاتورة {number}"
                });
            }
            else if (req.Payment == PaymentMethod.Credit)
            {
                // آجل: من ح/ ذمم مدينة
                journal.Add(new JournalLine
                {
                    AccountCode = RECEIVABLES,
                    AccountName = "ذمم مدينة - عملاء",
                    Debit       = total,
                    Note        = $"فاتورة آجلة {number} / {req.PartyName}"
                });
            }
            else if (req.Payment == PaymentMethod.Partial)
            {
                // مختلط: نقدي + ذمم
                if (req.PaidAmount > 0)
                    journal.Add(new JournalLine
                    {
                        AccountCode = CASH,
                        AccountName = "النقدية",
                        Debit       = req.PaidAmount,
                        Note        = $"دفعة نقدية / {number}"
                    });
                if (remaining > 0)
                    journal.Add(new JournalLine
                    {
                        AccountCode = RECEIVABLES,
                        AccountName = "ذمم مدينة - عملاء",
                        Debit       = remaining,
                        Note        = $"رصيد آجل / {req.PartyName}"
                    });
            }

            // إيراد المبيعات
            journal.Add(new JournalLine
            {
                AccountCode = SALES_REV,
                AccountName = "إيرادات المبيعات",
                Credit      = subtotal,
                Note        = $"مبيعات {number}"
            });

            // الخصم (إن وجد)
            if (discAmt > 0)
                journal.Add(new JournalLine
                {
                    AccountCode = SALES_DISC,
                    AccountName = "خصم مسموح به",
                    Debit       = discAmt,
                    Note        = $"خصم {req.DiscountPercent}%"
                });

            // الضريبة (إن وجدت)
            if (taxAmt > 0)
                journal.Add(new JournalLine
                {
                    AccountCode = TAX_PAYABLE,
                    AccountName = "ضريبة القيمة المضافة",
                    Credit      = taxAmt,
                    Note        = $"ض.ق.م {req.TaxPercent}%"
                });

            // تحديث المخزون (COGS)
            foreach (var line in req.Lines)
            {
                var costPrice = await GetProductCostAsync(line.ProductId);
                var costTotal = costPrice * line.Quantity;

                if (costTotal > 0)
                {
                    journal.Add(new JournalLine
                    {
                        AccountCode = COGS,
                        AccountName = "تكلفة البضاعة المباعة",
                        Debit       = costTotal,
                        Note        = line.ProductName
                    });
                    journal.Add(new JournalLine
                    {
                        AccountCode = INVENTORY,
                        AccountName = "المخزون",
                        Credit      = costTotal,
                        Note        = $"صرف {line.Quantity} × {line.ProductName}"
                    });
                }
            }

            // التحقق من توازن القيد
            AssertJournalBalanced(journal, number);

            // حفظ في قاعدة البيانات
            await _db.SaveInvoiceAsync(req, number, journal);
            await _db.PostJournalEntriesAsync(journal, $"فاتورة مبيعات {number}", req.Date);
            await _db.UpdateCustomerBalanceAsync(req.CustomerId, remaining);
            await _db.UpdateStockAsync(req.Lines, isDecrease: true);

            return BuildResult(number, req, journal, "مبيعات");
        }

        // ===================================================
        // تسجيل فاتورة مشتريات مع القيود الكاملة
        // ===================================================
        public async Task<InvoiceResult> PostPurchaseInvoiceAsync(CreateInvoiceRequest req)
        {
            ValidateInvoice(req);

            var number    = await GenerateInvoiceNumber("PUR");
            var subtotal  = req.Subtotal;
            var discAmt   = req.DiscountAmount;
            var taxAmt    = req.TaxAmount;
            var total     = req.Total;
            var remaining = req.Remaining;

            var journal = new List<JournalLine>();

            // المخزون يزيد
            journal.Add(new JournalLine
            {
                AccountCode = INVENTORY,
                AccountName = "المخزون",
                Debit       = subtotal - discAmt,
                Note        = $"استلام بضاعة / {number}"
            });

            // الضريبة
            if (taxAmt > 0)
                journal.Add(new JournalLine
                {
                    AccountCode = "1310", // ض.ق.م قابل للخصم
                    AccountName = "ضريبة قيمة مضافة - مدخلات",
                    Debit       = taxAmt,
                    Note        = $"ض.ق.م مشتريات {req.TaxPercent}%"
                });

            // الدفع
            if (req.Payment == PaymentMethod.Cash)
            {
                journal.Add(new JournalLine
                {
                    AccountCode = CASH,
                    AccountName = "النقدية",
                    Credit      = total,
                    Note        = $"سداد {number} نقداً"
                });
            }
            else if (req.Payment == PaymentMethod.Credit)
            {
                journal.Add(new JournalLine
                {
                    AccountCode = PAYABLES,
                    AccountName = "ذمم دائنة - موردين",
                    Credit      = total,
                    Note        = $"مستحق للمورد {req.PartyName}"
                });
            }
            else if (req.Payment == PaymentMethod.Partial)
            {
                if (req.PaidAmount > 0)
                    journal.Add(new JournalLine
                    {
                        AccountCode = CASH,
                        AccountName = "النقدية",
                        Credit      = req.PaidAmount,
                        Note        = $"دفعة نقدية / {number}"
                    });
                if (remaining > 0)
                    journal.Add(new JournalLine
                    {
                        AccountCode = PAYABLES,
                        AccountName = "ذمم دائنة - موردين",
                        Credit      = remaining,
                        Note        = $"رصيد مؤجل / {req.PartyName}"
                    });
            }

            AssertJournalBalanced(journal, number);

            await _db.SaveInvoiceAsync(req, number, journal);
            await _db.PostJournalEntriesAsync(journal, $"فاتورة مشتريات {number}", req.Date);
            await _db.UpdateSupplierBalanceAsync(req.SupplierId, remaining);
            await _db.UpdateStockAsync(req.Lines, isDecrease: false);

            return BuildResult(number, req, journal, "مشتريات");
        }

        // ===================================================
        // تسجيل مردود مبيعات (عكس فاتورة)
        // ===================================================
        public async Task<InvoiceResult> PostSalesReturnAsync(CreateInvoiceRequest req)
        {
            req.Type = InvoiceType.SalesReturn;
            var number  = await GenerateInvoiceNumber("RTN");
            var total   = req.Total;
            var journal = new List<JournalLine>();

            journal.Add(new JournalLine { AccountCode = SALES_REV, AccountName = "مردود مبيعات", Debit = total, Note = $"مردود {number}" });
            journal.Add(new JournalLine { AccountCode = CASH, AccountName = "النقدية", Credit = total, Note = $"استرداد {number}" });
            journal.Add(new JournalLine { AccountCode = INVENTORY, AccountName = "المخزون", Debit = req.Lines.Sum(l => l.LineTotal), Note = "إعادة للمخزون" });
            journal.Add(new JournalLine { AccountCode = COGS, AccountName = "تكلفة مباعة", Credit = req.Lines.Sum(l => l.LineTotal), Note = "مردود" });

            await _db.PostJournalEntriesAsync(journal, $"مردود مبيعات {number}", req.Date);
            await _db.UpdateStockAsync(req.Lines, isDecrease: false);

            return BuildResult(number, req, journal, "مردود مبيعات");
        }

        // ===================================================
        // تسجيل دفعة / تحصيل
        // ===================================================
        public async Task<ToolResult> RecordCollectionAsync(int customerId, decimal amount, string note)
        {
            var journal = new List<JournalLine>
            {
                new() { AccountCode = CASH,        AccountName = "النقدية",      Debit  = amount, Note = note },
                new() { AccountCode = RECEIVABLES, AccountName = "ذمم مدينة",    Credit = amount, Note = note }
            };
            AssertJournalBalanced(journal, "تحصيل");
            await _db.PostJournalEntriesAsync(journal, note, DateTime.Today);
            await _db.UpdateCustomerBalanceAsync(customerId, -amount);

            return new ToolResult { Success = true, Message = $"✅ تم تسجيل تحصيل {amount:N2} ج.م بنجاح." };
        }

        // ===================================================
        // تسجيل مصروف
        // ===================================================
        public async Task<ToolResult> RecordExpenseAsync(string expenseAccount, string accountName, decimal amount, string description)
        {
            var journal = new List<JournalLine>
            {
                new() { AccountCode = expenseAccount, AccountName = accountName, Debit  = amount, Note = description },
                new() { AccountCode = CASH,           AccountName = "النقدية",   Credit = amount, Note = description }
            };
            await _db.PostJournalEntriesAsync(journal, description, DateTime.Today);
            return new ToolResult { Success = true, Message = $"✅ تم تسجيل مصروف ({description}) بمبلغ {amount:N2} ج.م" };
        }

        // ===================================================
        // التقارير المالية
        // ===================================================
        public async Task<FinancialSummary> GetDailySummaryAsync(DateTime date)
        {
            return await _db.GetFinancialSummaryAsync(date, date);
        }

        public async Task<FinancialSummary> GetPeriodSummaryAsync(DateTime from, DateTime to)
        {
            return await _db.GetFinancialSummaryAsync(from, to);
        }

        public async Task<List<JournalLine>> GetTrialBalanceAsync()
        {
            return await _db.GetTrialBalanceAsync();
        }

        public async Task<AccountStatement> GetCustomerStatementAsync(int customerId, DateTime from, DateTime to)
        {
            return await _db.GetCustomerStatementAsync(customerId, from, to);
        }

        // ===================================================
        // دوال مساعدة خاصة
        // ===================================================
        private void ValidateInvoice(CreateInvoiceRequest req)
        {
            if (!req.Lines.Any())
                throw new InvalidOperationException("الفاتورة لا تحتوي على أصناف.");
            if (req.Lines.Any(l => l.Quantity <= 0 || l.UnitPrice <= 0))
                throw new InvalidOperationException("توجد بنود بكمية أو سعر غير صحيح.");
            if (req.Payment == PaymentMethod.Partial && req.PaidAmount <= 0)
                throw new InvalidOperationException("يجب تحديد المبلغ المدفوع في حالة الدفع الجزئي.");
        }

        private void AssertJournalBalanced(List<JournalLine> journal, string ref_)
        {
            var totalDebit  = journal.Sum(j => j.Debit);
            var totalCredit = journal.Sum(j => j.Credit);
            if (Math.Abs(totalDebit - totalCredit) > 0.01m)
                throw new InvalidOperationException(
                    $"القيد {ref_} غير متوازن! مدين={totalDebit:N2} | دائن={totalCredit:N2}");
        }

        private async Task<decimal> GetProductCostAsync(int? productId)
        {
            if (productId == null) return 0;
            return await _db.GetProductCostAsync(productId.Value);
        }

        private async Task<string> GenerateInvoiceNumber(string prefix)
        {
            var seq = await _db.GetNextSequenceAsync(prefix);
            return $"{prefix}-{DateTime.Now:yyMM}-{seq:D4}";
        }

        private InvoiceResult BuildResult(string number, CreateInvoiceRequest req, List<JournalLine> journal, string type)
        {
            var receipt = BuildReceiptText(number, req, type);
            return new InvoiceResult
            {
                InvoiceNumber  = number,
                Subtotal       = req.Subtotal,
                DiscountAmt    = req.DiscountAmount,
                TaxAmount      = req.TaxAmount,
                Total          = req.Total,
                PaidAmount     = req.PaidAmount,
                Remaining      = req.Remaining,
                JournalEntries = journal,
                ReceiptText    = receipt
            };
        }

        private string BuildReceiptText(string number, CreateInvoiceRequest req, string type)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("================================");
            sb.AppendLine($"      فاتورة {type}     ");
            sb.AppendLine($"  {number}  |  {req.Date:dd/MM/yyyy}  ");
            sb.AppendLine("================================");
            if (!string.IsNullOrEmpty(req.PartyName))
                sb.AppendLine($"العميل/المورد: {req.PartyName}");
            sb.AppendLine("--------------------------------");
            foreach (var l in req.Lines)
                sb.AppendLine($"{l.ProductName,-20} {l.Quantity}×{l.UnitPrice:N2} = {l.LineTotal:N2}");
            sb.AppendLine("--------------------------------");
            if (req.DiscountAmount > 0) sb.AppendLine($"خصم ({req.DiscountPercent}%):    -{req.DiscountAmount:N2}");
            if (req.TaxAmount > 0)      sb.AppendLine($"ض.ق.م ({req.TaxPercent}%):  +{req.TaxAmount:N2}");
            sb.AppendLine($"الإجمالي:           {req.Total:N2} ج.م");
            if (req.Payment == PaymentMethod.Partial || req.Payment == PaymentMethod.Cash)
                sb.AppendLine($"المدفوع:            {req.PaidAmount:N2} ج.م");
            if (req.Remaining > 0)
                sb.AppendLine($"المتبقي:            {req.Remaining:N2} ج.م");
            sb.AppendLine("================================");
            sb.AppendLine("       شكراً لتعاملكم معنا     ");
            return sb.ToString();
        }
    }

    // ===================================================
    // واجهة قاعدة البيانات - اربطها بـ DbContext الخاص بك
    // ===================================================
    public interface IAccountingDb
    {
        Task SaveInvoiceAsync(CreateInvoiceRequest req, string number, List<JournalLine> journal);
        Task PostJournalEntriesAsync(List<JournalLine> journal, string description, DateTime date);
        Task UpdateCustomerBalanceAsync(int? customerId, decimal delta);
        Task UpdateSupplierBalanceAsync(int? supplierId, decimal delta);
        Task UpdateStockAsync(List<InvoiceLineDto> lines, bool isDecrease);
        Task<decimal> GetProductCostAsync(int productId);
        Task<int> GetNextSequenceAsync(string prefix);
        Task<FinancialSummary> GetFinancialSummaryAsync(DateTime from, DateTime to);
        Task<List<JournalLine>> GetTrialBalanceAsync();
        Task<AccountStatement> GetCustomerStatementAsync(int customerId, DateTime from, DateTime to);
    }
}
