using SmartAccountingAgent.Models;
using SmartAccountingAgent.Services.Accounting;

namespace SmartAccountingAgent.Services.POS
{
    // ===================================================
    // محرك نقطة البيع (POS) المدمج في المحادثة
    // ===================================================
    public class POSService
    {
        private readonly AccountingEngine _accounting;
        private readonly IProductRepository _products;

        public POSService(AccountingEngine accounting, IProductRepository products)
        {
            _accounting = accounting;
            _products   = products;
        }

        // ===== إضافة صنف للعربة (بالاسم أو الباركود) =====
        public async Task<(bool Success, string Message, POSCartState Cart)> AddItemAsync(
            POSCartState cart, string query, decimal quantity = 1)
        {
            ProductLookup? product = null;

            // بحث بالباركود أولاً (أسرع)
            if (long.TryParse(query, out _))
                product = await _products.FindByBarcodeAsync(query);

            // ثم بالاسم أو الكود
            product ??= await _products.FindByNameOrCodeAsync(query);

            if (product == null)
                return (false, $"❌ لم أجد منتجاً بـ \"{query}\".\nتحقق من الاسم أو الباركود.", cart);

            if (!product.InStock)
                return (false, $"⚠️ {product.Name} نفذ من المخزون! المتاح: {product.Stock} وحدة.", cart);

            if (quantity > product.Stock)
                return (false, $"⚠️ الكمية المطلوبة ({quantity}) تتجاوز المخزون ({product.Stock}).", cart);

            // تحقق هل الصنف موجود في العربة مسبقاً
            var existing = cart.Items.FirstOrDefault(i => i.ProductId == product.Id);
            if (existing != null)
            {
                existing.Quantity += quantity;
                return (true, $"✅ تم تحديث {product.Name}: {existing.Quantity} وحدة × {product.SalePrice:N2}", cart);
            }

            cart.Items.Add(new POSCartItem
            {
                ProductId   = product.Id,
                ProductName = product.Name,
                Barcode     = product.Barcode,
                Quantity    = quantity,
                UnitPrice   = product.SalePrice
            });

            return (true, $"✅ تمت إضافة: {product.Name} × {quantity} بسعر {product.SalePrice:N2} ج.م", cart);
        }

        // ===== حذف صنف من العربة =====
        public (bool Success, string Message, POSCartState Cart) RemoveItem(POSCartState cart, string productName)
        {
            var item = cart.Items.FirstOrDefault(i =>
                i.ProductName.Contains(productName, StringComparison.OrdinalIgnoreCase));

            if (item == null)
                return (false, $"❌ لم أجد \"{productName}\" في الطلب.", cart);

            cart.Items.Remove(item);
            return (true, $"🗑️ تم حذف {item.ProductName} من الطلب.", cart);
        }

        // ===== ملخص العربة =====
        public string GetCartSummary(POSCartState cart)
        {
            if (cart.IsEmpty)
                return "🛒 العربة فارغة. أضف أصنافاً للبدء.";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine("🛒 **الطلب الحالي:**");
            sb.AppendLine("```");
            sb.AppendLine($"{"الصنف",-22} {"الكمية",6} {"السعر",8} {"الإجمالي",10}");
            sb.AppendLine(new string('-', 50));

            foreach (var item in cart.Items)
                sb.AppendLine($"{item.ProductName,-22} {item.Quantity,6} {item.UnitPrice,8:N2} {item.LineTotal,10:N2}");

            sb.AppendLine(new string('-', 50));
            if (cart.DiscountPercent > 0)
                sb.AppendLine($"{"خصم " + cart.DiscountPercent + "%",-36} {-cart.DiscountAmt,10:N2}");
            sb.AppendLine($"{"الإجمالي",-36} {cart.Total,10:N2} ج.م");
            sb.AppendLine("```");

            if (!string.IsNullOrEmpty(cart.CustomerName))
                sb.AppendLine($"👤 العميل: {cart.CustomerName}");

            sb.AppendLine("\nاكتب **\"ادفع\"** لإتمام البيع أو **\"أضف [صنف]\"** لإضافة المزيد.");
            return sb.ToString();
        }

        // ===== إتمام البيع (Checkout) =====
        public async Task<(bool Success, string Message, InvoiceResult? Result)> CheckoutAsync(
            POSCartState cart, decimal paidAmount)
        {
            if (cart.IsEmpty)
                return (false, "❌ لا توجد أصناف في الطلب.", null);

            if (paidAmount < cart.Total)
                return (false, $"❌ المبلغ المدفوع ({paidAmount:N2}) أقل من الإجمالي ({cart.Total:N2}).", null);

            try
            {
                var req = new CreateInvoiceRequest
                {
                    Type        = InvoiceType.Sales,
                    PartyName   = cart.CustomerName ?? "عميل نقدي",
                    CustomerId  = cart.CustomerId,
                    Payment     = PaymentMethod.Cash,
                    PaidAmount  = paidAmount,
                    Lines       = cart.Items.Select(i => new InvoiceLineDto
                    {
                        ProductId   = i.ProductId,
                        ProductName = i.ProductName,
                        Quantity    = i.Quantity,
                        UnitPrice   = i.UnitPrice,
                        Discount    = i.Discount
                    }).ToList(),
                    DiscountPercent = cart.DiscountPercent,
                    Date        = DateTime.Today
                };

                var result = await _accounting.PostSalesInvoiceAsync(req);

                var change    = paidAmount - cart.Total;
                var changeMsg = change > 0 ? $"\n💵 الباقي للعميل: **{change:N2} ج.م**" : "";

                var msg = $"✅ **تم إتمام البيع بنجاح!**\n" +
                          $"رقم الفاتورة: `{result.InvoiceNumber}`\n" +
                          $"الإجمالي: **{result.Total:N2} ج.م**\n" +
                          $"المدفوع: **{paidAmount:N2} ج.م**{changeMsg}";

                return (true, msg, result);
            }
            catch (Exception ex)
            {
                return (false, $"❌ خطأ في تسجيل البيع: {ex.Message}", null);
            }
        }

        // ===== البحث السريع عن منتج =====
        public async Task<string> QuickSearchAsync(string query)
        {
            var results = await _products.SearchAsync(query, maxResults: 5);
            if (!results.Any())
                return $"❌ لا توجد نتائج لـ \"{query}\"";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"🔍 نتائج البحث عن \"{query}\":");
            foreach (var p in results)
                sb.AppendLine($"• {p.Name} | سعر: {p.SalePrice:N2} | مخزون: {p.Stock}");
            return sb.ToString();
        }
    }

    // ===================================================
    // واجهة مستودع المنتجات
    // ===================================================
    public interface IProductRepository
    {
        Task<ProductLookup?> FindByBarcodeAsync(string barcode);
        Task<ProductLookup?> FindByNameOrCodeAsync(string query);
        Task<List<ProductLookup>> SearchAsync(string query, int maxResults = 10);
        Task<List<ProductLookup>> GetLowStockAsync(decimal threshold = 10);
        Task<decimal> GetStockAsync(int productId);
    }
}
