using Microsoft.EntityFrameworkCore;
using SmartAccountingAgent.Models;
using SmartAccountingAgent.Services.Accounting;

namespace SmartAccountingAgent.Data
{
    // ===================================================
    // DbContext الرئيسي — يدعم SQLite و SQL Server معاً
    // ===================================================
    public class AccountingDbContext : DbContext, IAccountingDb
    {
        public AccountingDbContext(DbContextOptions<AccountingDbContext> options) : base(options) { }

        // ===== الجداول =====
        public DbSet<CustomerEntity>     Customers      => Set<CustomerEntity>();
        public DbSet<SupplierEntity>     Suppliers      => Set<SupplierEntity>();
        public DbSet<ProductEntity>      Products       => Set<ProductEntity>();
        public DbSet<InvoiceEntity>      Invoices       => Set<InvoiceEntity>();
        public DbSet<InvoiceLineEntity>  InvoiceLines   => Set<InvoiceLineEntity>();
        public DbSet<JournalEntryEntity> JournalEntries => Set<JournalEntryEntity>();
        public DbSet<SequenceEntity>     Sequences      => Set<SequenceEntity>();

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<CustomerEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.Name).IsRequired().HasMaxLength(200);
                e.Property(x => x.Balance).HasColumnType("decimal(18,2)");
                e.HasIndex(x => x.Name);
            });
            mb.Entity<SupplierEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.Name).IsRequired().HasMaxLength(200);
                e.Property(x => x.Balance).HasColumnType("decimal(18,2)");
                e.HasIndex(x => x.Name);
            });
            mb.Entity<ProductEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.SalePrice).HasColumnType("decimal(18,2)");
                e.Property(x => x.CostPrice).HasColumnType("decimal(18,2)");
                e.Property(x => x.Stock).HasColumnType("decimal(18,3)");
                e.HasIndex(x => x.Barcode);
                e.HasIndex(x => x.Code);
            });
            mb.Entity<InvoiceEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.Total).HasColumnType("decimal(18,2)");
                e.HasMany(x => x.Lines).WithOne(l => l.Invoice).HasForeignKey(l => l.InvoiceId);
            });
            mb.Entity<InvoiceLineEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.UnitPrice).HasColumnType("decimal(18,2)");
                e.Property(x => x.Quantity).HasColumnType("decimal(18,3)");
                e.Property(x => x.LineTotal).HasColumnType("decimal(18,2)");
            });
            mb.Entity<JournalEntryEntity>(e => {
                e.HasKey(x => x.Id);
                e.Property(x => x.Debit).HasColumnType("decimal(18,2)");
                e.Property(x => x.Credit).HasColumnType("decimal(18,2)");
                e.HasIndex(x => x.EntryDate);
                e.HasIndex(x => x.AccountCode);
            });
            mb.Entity<SequenceEntity>(e => { e.HasKey(x => x.Prefix); });
        }

        // ===================================================
        // تطبيق IAccountingDb — كل العمليات المحاسبية
        // ===================================================

        public async Task SaveInvoiceAsync(CreateInvoiceRequest req, string number, List<JournalLine> journal)
        {
            Invoices.Add(new InvoiceEntity
            {
                Number     = number,
                Type       = req.Type.ToString(),
                PartyName  = req.PartyName,
                CustomerId = req.CustomerId,
                SupplierId = req.SupplierId,
                Date       = req.Date,
                Total      = req.Total,
                PaidAmount = req.PaidAmount,
                Remaining  = req.Remaining,
                Notes      = req.Notes,
                CreatedAt  = DateTime.Now,
                Lines      = req.Lines.Select(l => new InvoiceLineEntity
                {
                    ProductId   = l.ProductId,
                    ProductName = l.ProductName,
                    Quantity    = l.Quantity,
                    UnitPrice   = l.UnitPrice,
                    Discount    = l.Discount,
                    LineTotal   = l.LineTotal
                }).ToList()
            });
            await SaveChangesAsync();
        }

        public async Task PostJournalEntriesAsync(List<JournalLine> lines, string description, DateTime date)
        {
            var refNum = $"JE-{date:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..6].ToUpper()}";
            JournalEntries.AddRange(lines.Select(l => new JournalEntryEntity
            {
                Reference   = refNum,
                Description = description,
                AccountCode = l.AccountCode,
                AccountName = l.AccountName,
                Debit       = l.Debit,
                Credit      = l.Credit,
                Note        = l.Note,
                EntryDate   = date,
                CreatedAt   = DateTime.Now
            }));
            await SaveChangesAsync();
        }

        public async Task UpdateCustomerBalanceAsync(int? customerId, decimal delta)
        {
            if (customerId is null or 0) return;
            var c = await Customers.FindAsync(customerId);
            if (c != null) { c.Balance += delta; await SaveChangesAsync(); }
        }

        public async Task UpdateSupplierBalanceAsync(int? supplierId, decimal delta)
        {
            if (supplierId is null or 0) return;
            var s = await Suppliers.FindAsync(supplierId);
            if (s != null) { s.Balance += delta; await SaveChangesAsync(); }
        }

        public async Task UpdateStockAsync(List<InvoiceLineDto> lines, bool isDecrease)
        {
            foreach (var line in lines.Where(l => l.ProductId.HasValue))
            {
                var p = await Products.FindAsync(line.ProductId!.Value);
                if (p == null) continue;
                p.Stock = isDecrease
                    ? Math.Max(0, p.Stock - line.Quantity)
                    : p.Stock + line.Quantity;
            }
            await SaveChangesAsync();
        }

        public async Task<decimal> GetProductCostAsync(int productId)
        {
            var p = await Products.FindAsync(productId);
            return p?.CostPrice ?? 0;
        }

        public async Task<int> GetNextSequenceAsync(string prefix)
        {
            var seq = await Sequences.FindAsync(prefix);
            if (seq == null) { seq = new SequenceEntity { Prefix = prefix, LastValue = 0 }; Sequences.Add(seq); }
            seq.LastValue++;
            await SaveChangesAsync();
            return seq.LastValue;
        }

        public async Task<FinancialSummary> GetFinancialSummaryAsync(DateTime from, DateTime to)
        {
            var toEnd = to.Date.AddDays(1);

            var sales = await Invoices
                .Where(i => i.Type == "Sales" && i.Date >= from && i.Date < toEnd)
                .GroupBy(_ => 1)
                .Select(g => new { Total = g.Sum(i => i.Total), Count = g.Count() })
                .FirstOrDefaultAsync();

            var purch = await Invoices
                .Where(i => i.Type == "Purchase" && i.Date >= from && i.Date < toEnd)
                .GroupBy(_ => 1)
                .Select(g => new { Total = g.Sum(i => i.Total), Count = g.Count() })
                .FirstOrDefaultAsync();

            var cash = await JournalEntries
                .Where(j => j.AccountCode == "1010")
                .SumAsync(j => (decimal?)(j.Debit - j.Credit)) ?? 0;

            var cogs = await JournalEntries
                .Where(j => j.AccountCode == "5010" && j.EntryDate >= from && j.EntryDate < toEnd)
                .SumAsync(j => (decimal?)j.Debit) ?? 0;

            var receivables = await Customers
                .Where(c => c.Balance > 0).SumAsync(c => (decimal?)c.Balance) ?? 0;
            var payables = await Suppliers
                .Where(s => s.Balance > 0).SumAsync(s => (decimal?)s.Balance) ?? 0;

            var st = sales?.Total ?? 0;
            var pt = purch?.Total ?? 0;

            return new FinancialSummary
            {
                TotalSales       = st,
                TotalPurchases   = pt,
                TotalReceivables = receivables,
                TotalPayables    = payables,
                CashBalance      = cash,
                GrossProfit      = st - cogs,
                NetProfit        = st - cogs,
                SalesCount       = sales?.Count ?? 0,
                PurchaseCount    = purch?.Count ?? 0,
                From             = from,
                To               = to
            };
        }

        public async Task<List<JournalLine>> GetTrialBalanceAsync() =>
            await JournalEntries
                .GroupBy(j => new { j.AccountCode, j.AccountName })
                .Select(g => new JournalLine
                {
                    AccountCode = g.Key.AccountCode,
                    AccountName = g.Key.AccountName,
                    Debit       = g.Sum(j => j.Debit),
                    Credit      = g.Sum(j => j.Credit)
                })
                .OrderBy(j => j.AccountCode)
                .ToListAsync();

        public async Task<AccountStatement> GetCustomerStatementAsync(
            int customerId, DateTime from, DateTime to)
        {
            var customer = await Customers.FindAsync(customerId);
            var toEnd    = to.Date.AddDays(1);
            var name     = customer?.Name ?? "";

            var entries = await JournalEntries
                .Where(j => j.EntryDate >= from && j.EntryDate < toEnd
                         && (j.Note != null && j.Note.Contains(name)))
                .OrderBy(j => j.EntryDate)
                .ToListAsync();

            decimal running = 0;
            var lines = entries.Select(e => {
                running += e.Debit - e.Credit;
                return new StatementLine
                {
                    Date        = e.EntryDate,
                    Description = e.Description,
                    Debit       = e.Debit,
                    Credit      = e.Credit,
                    Balance     = running
                };
            }).ToList();

            return new AccountStatement
            {
                AccountCode = customerId.ToString(),
                AccountName = name,
                OpeningBal  = 0,
                Lines       = lines
            };
        }
    }

    // ===================================================
    // كيانات قاعدة البيانات (Entities)
    // ===================================================
    public class CustomerEntity
    {
        public int     Id        { get; set; }
        public string  Name      { get; set; } = string.Empty;
        public string? Phone     { get; set; }
        public string? Address   { get; set; }
        public string? TaxNumber { get; set; }
        public string? Email     { get; set; }
        public decimal Balance   { get; set; }
        public bool    IsActive  { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    public class SupplierEntity
    {
        public int     Id        { get; set; }
        public string  Name      { get; set; } = string.Empty;
        public string? Phone     { get; set; }
        public string? Address   { get; set; }
        public string? TaxNumber { get; set; }
        public string? Email     { get; set; }
        public decimal Balance   { get; set; }
        public bool    IsActive  { get; set; } = true;
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    public class ProductEntity
    {
        public int     Id        { get; set; }
        public string  Name      { get; set; } = string.Empty;
        public string? Code      { get; set; }
        public string? Barcode   { get; set; }
        public int?    CategoryId { get; set; }
        public decimal SalePrice { get; set; }
        public decimal CostPrice { get; set; }
        public decimal Stock     { get; set; }
        public decimal MinStock  { get; set; } = 10;
        public bool    IsActive  { get; set; } = true;
    }

    public class InvoiceEntity
    {
        public int     Id         { get; set; }
        public string  Number     { get; set; } = string.Empty;
        public string  Type       { get; set; } = string.Empty;
        public string  PartyName  { get; set; } = string.Empty;
        public int?    CustomerId { get; set; }
        public int?    SupplierId { get; set; }
        public DateTime Date      { get; set; }
        public decimal Total      { get; set; }
        public decimal PaidAmount { get; set; }
        public decimal Remaining  { get; set; }
        public string? Notes      { get; set; }
        public DateTime CreatedAt { get; set; }
        public List<InvoiceLineEntity> Lines { get; set; } = new();
    }

    public class InvoiceLineEntity
    {
        public int     Id          { get; set; }
        public int     InvoiceId   { get; set; }
        public int?    ProductId   { get; set; }
        public string  ProductName { get; set; } = string.Empty;
        public decimal Quantity    { get; set; }
        public decimal UnitPrice   { get; set; }
        public decimal Discount    { get; set; }
        public decimal LineTotal   { get; set; }
        public InvoiceEntity Invoice { get; set; } = null!;
    }

    public class JournalEntryEntity
    {
        public int     Id          { get; set; }
        public string  Reference   { get; set; } = string.Empty;
        public string  Description { get; set; } = string.Empty;
        public string  AccountCode { get; set; } = string.Empty;
        public string  AccountName { get; set; } = string.Empty;
        public decimal Debit       { get; set; }
        public decimal Credit      { get; set; }
        public string? Note        { get; set; }
        public DateTime EntryDate  { get; set; }
        public DateTime CreatedAt  { get; set; }
    }

    public class SequenceEntity
    {
        public string Prefix    { get; set; } = string.Empty;
        public int    LastValue { get; set; }
    }
}
