using Microsoft.EntityFrameworkCore;
using SmartAccountingAgent.Agent.Core;
using SmartAccountingAgent.Models;
using SmartAccountingAgent.Services.POS;

namespace SmartAccountingAgent.Data
{
    // ===================================================
    // مستودع المنتجات — IProductRepository
    // ===================================================
    public class ProductRepository : IProductRepository
    {
        private readonly AccountingDbContext _db;
        public ProductRepository(AccountingDbContext db) => _db = db;

        public async Task<ProductLookup?> FindByBarcodeAsync(string barcode) =>
            await _db.Products
                .Where(p => p.IsActive && p.Barcode == barcode)
                .Select(Map())
                .FirstOrDefaultAsync();

        public async Task<ProductLookup?> FindByNameOrCodeAsync(string query)
        {
            var q = query.ToLower();
            return await _db.Products
                .Where(p => p.IsActive && (
                    p.Name.ToLower().Contains(q) ||
                    (p.Code != null && p.Code.ToLower().Contains(q))))
                .OrderBy(p => p.Name.ToLower().StartsWith(q) ? 0 : 1)
                .Select(Map())
                .FirstOrDefaultAsync();
        }

        public async Task<List<ProductLookup>> SearchAsync(string query, int maxResults = 10)
        {
            var q = query.ToLower();
            return await _db.Products
                .Where(p => p.IsActive && (
                    p.Name.ToLower().Contains(q) ||
                    (p.Code    != null && p.Code.ToLower().Contains(q)) ||
                    (p.Barcode != null && p.Barcode.Contains(query))))
                .OrderBy(p => p.Name)
                .Take(maxResults)
                .Select(Map())
                .ToListAsync();
        }

        public async Task<List<ProductLookup>> GetLowStockAsync(decimal threshold = 10) =>
            await _db.Products
                .Where(p => p.IsActive && p.Stock <= p.MinStock)
                .OrderBy(p => p.Stock)
                .Select(Map())
                .ToListAsync();

        public async Task<decimal> GetStockAsync(int productId)
        {
            var p = await _db.Products.FindAsync(productId);
            return p?.Stock ?? 0;
        }

        // مساعد: تحويل Entity → DTO
        private static System.Linq.Expressions.Expression<
            Func<ProductEntity, ProductLookup>> Map() =>
            p => new ProductLookup
            {
                Id        = p.Id,
                Name      = p.Name,
                Code      = p.Code,
                Barcode   = p.Barcode,
                SalePrice = p.SalePrice,
                CostPrice = p.CostPrice,
                Stock     = p.Stock
            };
    }

    // ===================================================
    // مستودع العملاء والموردين — IPartyRepository
    // ===================================================
    public class PartyRepository : IPartyRepository
    {
        private readonly AccountingDbContext _db;
        public PartyRepository(AccountingDbContext db) => _db = db;

        // ===== عملاء =====
        public async Task<CustomerDto?> FindCustomerByNameAsync(string name)
        {
            var n = name.ToLower();
            var c = await _db.Customers
                .Where(x => x.IsActive && x.Name.ToLower().Contains(n))
                .FirstOrDefaultAsync();
            return c == null ? null : MapCustomer(c);
        }

        public async Task<List<CustomerDto>> SearchCustomersAsync(string query)
        {
            var q = query.ToLower();
            return await _db.Customers
                .Where(c => c.IsActive && (
                    c.Name.ToLower().Contains(q) ||
                    (c.Phone != null && c.Phone.Contains(query))))
                .OrderBy(c => c.Name)
                .Take(10)
                .Select(c => new CustomerDto
                {
                    Id      = c.Id,
                    Name    = c.Name,
                    Phone   = c.Phone,
                    Address = c.Address,
                    Balance = c.Balance
                })
                .ToListAsync();
        }

        public async Task<CustomerDto> AddCustomerAsync(CustomerDto dto)
        {
            // تجنب التكرار
            var exists = await _db.Customers
                .FirstOrDefaultAsync(c => c.Name.ToLower() == dto.Name.ToLower());
            if (exists != null) return MapCustomer(exists);

            var entity = new CustomerEntity
            {
                Name      = dto.Name.Trim(),
                Phone     = dto.Phone?.Trim(),
                Address   = dto.Address?.Trim(),
                TaxNumber = dto.TaxNumber?.Trim(),
                Email     = dto.Email?.Trim(),
                Balance   = 0,
                IsActive  = true,
                CreatedAt = DateTime.Now
            };
            _db.Customers.Add(entity);
            await _db.SaveChangesAsync();
            return MapCustomer(entity);
        }

        // ===== موردون =====
        public async Task<SupplierDto?> FindSupplierByNameAsync(string name)
        {
            var n = name.ToLower();
            var s = await _db.Suppliers
                .Where(x => x.IsActive && x.Name.ToLower().Contains(n))
                .FirstOrDefaultAsync();
            return s == null ? null : MapSupplier(s);
        }

        public async Task<SupplierDto> AddSupplierAsync(SupplierDto dto)
        {
            var exists = await _db.Suppliers
                .FirstOrDefaultAsync(s => s.Name.ToLower() == dto.Name.ToLower());
            if (exists != null) return MapSupplier(exists);

            var entity = new SupplierEntity
            {
                Name      = dto.Name.Trim(),
                Phone     = dto.Phone?.Trim(),
                Address   = dto.Address?.Trim(),
                TaxNumber = dto.TaxNumber?.Trim(),
                Balance   = 0,
                IsActive  = true,
                CreatedAt = DateTime.Now
            };
            _db.Suppliers.Add(entity);
            await _db.SaveChangesAsync();
            return MapSupplier(entity);
        }

        // ===== منتجات (للتقارير) =====
        public async Task<List<ProductLookup>> GetTopProductsAsync(int count = 10)
        {
            // أكثر المنتجات مبيعاً من بنود الفواتير
            return await _db.InvoiceLines
                .Where(l => l.ProductId.HasValue)
                .GroupBy(l => new { l.ProductId, l.ProductName })
                .Select(g => new ProductLookup
                {
                    Id    = g.Key.ProductId!.Value,
                    Name  = g.Key.ProductName,
                    Stock = g.Sum(l => l.Quantity)   // إجمالي الكميات المباعة
                })
                .OrderByDescending(p => p.Stock)
                .Take(count)
                .ToListAsync();
        }

        public async Task<string> GetStockInfoAsync(string query)
        {
            var q = query.ToLower();
            var products = await _db.Products
                .Where(p => p.IsActive && p.Name.ToLower().Contains(q))
                .Take(5)
                .ToListAsync();

            if (!products.Any()) return $"❌ لم أجد منتجاً يطابق \"{query}\"";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"📦 **المخزون — نتائج البحث عن \"{query}\":**\n");
            foreach (var p in products)
            {
                var status = p.Stock <= p.MinStock ? "⚠️ منخفض" : "✅ متاح";
                sb.AppendLine($"• **{p.Name}** — المتاح: {p.Stock:N0} | {status}");
                if (!string.IsNullOrEmpty(p.Barcode))
                    sb.AppendLine($"  الباركود: `{p.Barcode}`");
            }
            return sb.ToString();
        }

        public async Task<List<ProductLookup>> GetLowStockItemsAsync(decimal threshold = 10)
        {
            return await _db.Products
                .Where(p => p.IsActive && p.Stock <= p.MinStock)
                .OrderBy(p => p.Stock)
                .Select(p => new ProductLookup
                {
                    Id      = p.Id,
                    Name    = p.Name,
                    Code    = p.Code,
                    Barcode = p.Barcode,
                    Stock   = p.Stock
                })
                .ToListAsync();
        }

        // ===== Mappers =====
        private static CustomerDto MapCustomer(CustomerEntity c) => new()
        {
            Id      = c.Id,
            Name    = c.Name,
            Phone   = c.Phone,
            Address = c.Address,
            Balance = c.Balance
        };

        private static SupplierDto MapSupplier(SupplierEntity s) => new()
        {
            Id      = s.Id,
            Name    = s.Name,
            Phone   = s.Phone,
            Address = s.Address,
            Balance = s.Balance
        };
    }
}
