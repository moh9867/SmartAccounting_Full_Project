using SmartAccountingAgent.Agent.NLP;
using SmartAccountingAgent.Models;
using SmartAccountingAgent.Services.Accounting;
using SmartAccountingAgent.Services.POS;

namespace SmartAccountingAgent.Agent.Core
{
    // ===================================================
    // الوكيل المحاسبي الرئيسي — المحرك الأساسي
    // ===================================================
    public class AccountingAgent
    {
        private readonly IntentDetector       _nlp;
        private readonly AccountingEngine     _accounting;
        private readonly POSService           _pos;
        private readonly IPartyRepository     _parties;
        private readonly SessionStore         _sessions;
        private readonly InvoiceParserService _parser;

        public AccountingAgent(
            AccountingEngine     accounting,
            POSService           pos,
            IPartyRepository     parties,
            SessionStore         sessions,
            InvoiceParserService parser)
        {
            _nlp        = new IntentDetector();
            _accounting = accounting;
            _pos        = pos;
            _parties    = parties;
            _sessions   = sessions;
            _parser     = parser;
        }

        // ===================================================
        // نقطة الدخول الرئيسية
        // ===================================================
        public async Task<AgentResponse> ProcessAsync(AgentRequest request)
        {
            var session = _sessions.GetOrCreate(request.SessionId, request.Channel, request.TelegramChatId);
            session.AddMessage("user", request.UserMessage);
            session.LastActivity = DateTime.Now;

            try
            {
                AgentResponse response;

                // ===== التحقق من وجود إجراء معلّق (Pending Action) =====
                if (session.PendingAction != null)
                {
                    response = await HandlePendingActionAsync(session, request.UserMessage);
                }
                // ===== قراءة صورة فاتورة =====
                else if (!string.IsNullOrEmpty(request.ImageBase64))
                {
                    response = await HandleInvoiceImageAsync(session, request.ImageBase64);
                }
                else
                {
                    // ===== كشف النية وتوجيه الطلب =====
                    var intent = _nlp.Detect(request.UserMessage);
                    response = await RouteIntentAsync(session, intent, request.UserMessage);
                }

                session.AddMessage("assistant", response.Message);
                return response;
            }
            catch (Exception ex)
            {
                session.PendingAction  = null;
                session.PendingInvoice = null;
                return Error($"❌ حدث خطأ: {ex.Message}\nاكتب **\"مساعدة\"** لعرض الأوامر المتاحة.");
            }
        }

        // ===================================================
        // توجيه النية للخدمة المناسبة
        // ===================================================
        private async Task<AgentResponse> RouteIntentAsync(
            ConversationSession session, IntentResult intent, string text)
        {
            return intent.Intent switch
            {
                // ===== مبيعات =====
                AgentIntent.CreateSalesInvoice    => await StartSalesInvoiceAsync(session, intent, text),
                AgentIntent.AddItemToInvoice      => await AddItemToInvoiceAsync(session, intent, text),
                AgentIntent.ConfirmInvoice        => await ConfirmInvoiceAsync(session),
                AgentIntent.CancelInvoice         => CancelPendingAction(session),

                // ===== مشتريات =====
                AgentIntent.CreatePurchaseInvoice => await StartPurchaseInvoiceAsync(session, intent, text),
                AgentIntent.ReadInvoiceFromImage  => AskForInvoiceImage(),

                // ===== POS =====
                AgentIntent.StartPOS              => StartPOS(session),
                AgentIntent.AddToPOSCart          => await AddToPOSAsync(session, intent, text),
                AgentIntent.CheckoutPOS           => await CheckoutPOSAsync(session, intent),
                AgentIntent.ClearPOSCart          => ClearPOSCart(session),

                // ===== عملاء/موردين =====
                AgentIntent.AddCustomer           => await StartAddCustomerAsync(session, intent),
                AgentIntent.AddSupplier           => await StartAddSupplierAsync(session, intent),
                AgentIntent.SearchCustomer        => await SearchCustomerAsync(intent, text),
                AgentIntent.GetCustomerBalance    => await GetCustomerBalanceAsync(intent, text),

                // ===== تقارير =====
                AgentIntent.GetDailySummary       => await GetDailySummaryAsync(intent),
                AgentIntent.GetCustomerStatement  => await GetCustomerStatementAsync(intent, text),
                AgentIntent.GetTrialBalance       => await GetTrialBalanceAsync(),
                AgentIntent.GetTopProducts        => await GetTopProductsAsync(),

                // ===== مخزون =====
                AgentIntent.CheckStock            => await CheckStockAsync(intent, text),
                AgentIntent.GetLowStock           => await GetLowStockAsync(),

                // ===== مدفوعات =====
                AgentIntent.RecordPayment         => await RecordPaymentAsync(intent, text),
                AgentIntent.RecordExpense         => await RecordExpenseAsync(intent, text),

                // ===== نظام =====
                AgentIntent.Help                  => ShowHelp(),
                AgentIntent.CancelAction          => CancelPendingAction(session),

                _                                 => HandleUnknown(text)
            };
        }

        // ===================================================
        // فاتورة مبيعات — بدء وإضافة وتأكيد
        // ===================================================
        private async Task<AgentResponse> StartSalesInvoiceAsync(
            ConversationSession session, IntentResult intent, string text)
        {
            session.PendingInvoice = new CreateInvoiceRequest { Type = InvoiceType.Sales };
            session.PendingAction  = "building_sales_invoice";

            // استخراج أول صنف إن وجد في الرسالة ذاتها
            if (intent.Entities.TryGetValue("product", out var product) &&
                intent.Entities.TryGetValue("price", out var priceStr) &&
                decimal.TryParse(priceStr, out var price))
            {
                decimal.TryParse(intent.Entities.GetValueOrDefault("quantity", "1"), out var qty);
                session.PendingInvoice.Lines.Add(new InvoiceLineDto
                {
                    ProductName = product,
                    Quantity    = qty > 0 ? qty : 1,
                    UnitPrice   = price
                });
            }

            // استخراج اسم العميل
            if (intent.Entities.TryGetValue("name", out var name))
            {
                session.PendingInvoice.PartyName = name;
                var customer = await _parties.FindCustomerByNameAsync(name);
                if (customer != null) session.PendingInvoice.CustomerId = customer.Id;
            }

            var summary = session.PendingInvoice.Lines.Any()
                ? FormatInvoiceLines(session.PendingInvoice)
                : "";

            return Reply(
                $"📋 **بدأت فاتورة مبيعات جديدة**{(string.IsNullOrEmpty(session.PendingInvoice.PartyName) ? "" : $" للعميل: {session.PendingInvoice.PartyName}")}\n\n" +
                (summary.Length > 0 ? summary + "\n\n" : "") +
                "أضف الأصناف بالصيغة:\n`أضف [اسم الصنف] [الكمية] بـ [السعر]`\n\n" +
                "ثم اكتب **\"تأكيد\"** لحفظ الفاتورة.",
                quickReplies: new[] { ("تأكيد","تأكيد"), ("إلغاء","إلغاء"), ("إضافة خصم","إضافة خصم") });
        }

        private async Task<AgentResponse> AddItemToInvoiceAsync(
            ConversationSession session, IntentResult intent, string text)
        {
            if (session.PendingInvoice == null)
                return await StartSalesInvoiceAsync(session, intent, text);

            if (!intent.Entities.TryGetValue("price", out var priceStr) ||
                !decimal.TryParse(priceStr, out var price))
                return Reply("أدخل سعر الصنف.\nمثال: `أضف سكر 5 كيلو بـ 45`");

            var productName = intent.Entities.GetValueOrDefault("product", "صنف غير محدد");
            decimal.TryParse(intent.Entities.GetValueOrDefault("quantity", "1"), out var qty);
            decimal.TryParse(intent.Entities.GetValueOrDefault("discount", "0"), out var disc);

            session.PendingInvoice.Lines.Add(new InvoiceLineDto
            {
                ProductName = productName,
                Quantity    = qty > 0 ? qty : 1,
                UnitPrice   = price,
                Discount    = disc
            });

            return Reply(
                $"✅ تمت الإضافة: **{productName}** × {qty} بـ {price:N2} = {(qty * price):N2} ج.م\n\n" +
                FormatInvoiceLines(session.PendingInvoice),
                quickReplies: new[] { ("تأكيد","تأكيد"), ("إلغاء","إلغاء") });
        }

        private async Task<AgentResponse> ConfirmInvoiceAsync(ConversationSession session)
        {
            if (session.PendingInvoice == null || !session.PendingInvoice.Lines.Any())
                return Reply("❌ لا توجد فاتورة جارية. قل **\"فاتورة بيع\"** للبدء.");

            InvoiceResult result;
            string actionLabel;

            if (session.PendingInvoice.Type == InvoiceType.Sales)
            {
                result      = await _accounting.PostSalesInvoiceAsync(session.PendingInvoice);
                actionLabel = "مبيعات";
            }
            else
            {
                result      = await _accounting.PostPurchaseInvoiceAsync(session.PendingInvoice);
                actionLabel = "مشتريات";
            }

            session.PendingAction  = null;
            session.PendingInvoice = null;

            return new AgentResponse
            {
                Message     = $"✅ **تم تسجيل فاتورة {actionLabel} بنجاح!**\n\n" +
                              $"📄 رقم الفاتورة: `{result.InvoiceNumber}`\n" +
                              $"💰 الإجمالي: **{result.Total:N2} ج.م**\n" +
                              (result.Remaining > 0 ? $"⏳ المتبقي: {result.Remaining:N2} ج.م\n" : "") +
                              $"\n**القيود المحاسبية:**\n{FormatJournal(result.JournalEntries)}",
                ActionTaken = $"posted_{actionLabel}_invoice",
                Data        = result,
                Type        = AgentResponseType.InvoicePreview,
                QuickReplies = new List<QuickReply>
                {
                    new("طباعة", "طباعة"), new("فاتورة جديدة", "فاتورة بيع")
                }
            };
        }

        // ===================================================
        // فاتورة مشتريات
        // ===================================================
        private async Task<AgentResponse> StartPurchaseInvoiceAsync(
            ConversationSession session, IntentResult intent, string text)
        {
            session.PendingInvoice = new CreateInvoiceRequest { Type = InvoiceType.Purchase };
            session.PendingAction  = "building_purchase_invoice";

            if (intent.Entities.TryGetValue("name", out var supplierName))
            {
                session.PendingInvoice.PartyName = supplierName;
                var supplier = await _parties.FindSupplierByNameAsync(supplierName);
                if (supplier != null) session.PendingInvoice.SupplierId = supplier.Id;
            }

            return Reply(
                "📦 **فاتورة مشتريات جديدة**" +
                (string.IsNullOrEmpty(session.PendingInvoice.PartyName) ? "\nاسم المورد؟" : $"\nالمورد: {session.PendingInvoice.PartyName}") +
                "\n\nأضف الأصناف: `أضف [صنف] [كمية] بـ [سعر]`",
                quickReplies: new[] { ("تأكيد","تأكيد"), ("إلغاء","إلغاء"), ("قراءة من صورة","صورة فاتورة") });
        }

        // ===================================================
        // POS - نقطة البيع
        // ===================================================
        private AgentResponse StartPOS(ConversationSession session)
        {
            session.POSCart       = new POSCartState();
            session.PendingAction = "pos_active";

            return Reply(
                "🏪 **وضع نقطة البيع نشط**\n\n" +
                "أضف أصنافاً بـ:\n" +
                "• `باركود [رقم]`\n• `أضف [اسم الصنف]`\n• `أضف [اسم] [كمية]`\n\n" +
                "ثم اكتب **\"ادفع [المبلغ]\"** لإتمام البيع.",
                quickReplies: new[] { ("عرض الطلب","عرض الطلب"), ("مسح الطلب","مسح الطلب") });
        }

        private async Task<AgentResponse> AddToPOSAsync(
            ConversationSession session, IntentResult intent, string text)
        {
            session.POSCart ??= new POSCartState();
            session.PendingAction = "pos_active";

            var query = intent.Entities.GetValueOrDefault("barcode")
                     ?? intent.Entities.GetValueOrDefault("product")
                     ?? ExtractAfterKeyword(text, new[]{"أضف","ضيف","باركود","scan"});

            if (string.IsNullOrWhiteSpace(query))
                return Reply("أدخل اسم الصنف أو الباركود.\nمثال: `أضف سكر` أو `باركود 6221234567890`");

            decimal.TryParse(intent.Entities.GetValueOrDefault("quantity","1"), out var qty);
            var (ok, msg, cart) = await _pos.AddItemAsync(session.POSCart, query, qty > 0 ? qty : 1);
            session.POSCart = cart;

            return Reply(ok ? $"{msg}\n\n{_pos.GetCartSummary(cart)}" : msg,
                quickReplies: new[] { ("عرض الطلب","عرض الطلب"), ("ادفع","ادفع") });
        }

        private async Task<AgentResponse> CheckoutPOSAsync(ConversationSession session, IntentResult intent)
        {
            if (session.POSCart == null || session.POSCart.IsEmpty)
                return Reply("🛒 العربة فارغة! أضف أصنافاً أولاً.");

            // استخراج المبلغ المدفوع
            var numbers = System.Text.RegularExpressions.Regex.Matches(
                session.POSCart.Total.ToString(), @"\d+(?:\.\d+)?");

            decimal paid = intent.Entities.TryGetValue("quantity", out var pStr)
                ? decimal.Parse(pStr) : session.POSCart.Total;

            var (ok, msg, result) = await _pos.CheckoutAsync(session.POSCart, paid);
            if (ok)
            {
                session.POSCart       = new POSCartState(); // عربة جديدة
                session.PendingAction = "pos_active";       // ابقَ في وضع POS
            }

            return new AgentResponse
            {
                Message      = msg,
                Data         = result,
                Type         = ok ? AgentResponseType.POSReceipt : AgentResponseType.Text,
                QuickReplies = new List<QuickReply>
                {
                    new("طلب جديد","طلب جديد"), new("طباعة","طباعة"), new("الخروج من POS","الخروج")
                }
            };
        }

        private AgentResponse ClearPOSCart(ConversationSession session)
        {
            session.POSCart = new POSCartState();
            return Reply("🗑️ تم مسح الطلب. ابدأ طلباً جديداً.",
                quickReplies: new[] { ("الخروج من POS","الخروج"), ("طلب جديد","طلب جديد") });
        }

        // ===================================================
        // قراءة فاتورة من صورة
        // ===================================================
        private async Task<AgentResponse> HandleInvoiceImageAsync(
            ConversationSession session, string imageBase64)
        {
            var parsed = await _parser.ParseFromBase64Async(imageBase64);
            if (parsed == null)
                return Error("❌ لم أتمكن من قراءة الفاتورة. تأكد من وضوح الصورة.");

            // بناء الفاتورة المعلّقة
            session.PendingInvoice = new CreateInvoiceRequest
            {
                Type       = InvoiceType.Purchase,
                PartyName  = parsed.SupplierName ?? "",
                Lines      = parsed.Lines,
                Date       = parsed.Date ?? DateTime.Today
            };
            session.PendingAction = "building_purchase_invoice";

            return Reply(
                $"📷 **تمت قراءة الفاتورة بنجاح** (دقة: {parsed.Confidence:P0})\n\n" +
                $"المورد: **{parsed.SupplierName ?? "غير محدد"}**\n" +
                $"التاريخ: {parsed.Date?.ToString("dd/MM/yyyy") ?? "غير محدد"}\n\n" +
                FormatInvoiceLines(session.PendingInvoice) +
                "\n\nهل البيانات صحيحة؟ اكتب **\"تأكيد\"** للحفظ أو صحّح أي بند.",
                quickReplies: new[] { ("تأكيد","تأكيد"), ("إلغاء","إلغاء") });
        }

        private AgentResponse AskForInvoiceImage() =>
            Reply("📷 أرسل صورة الفاتورة وسأقرأها تلقائياً.");

        // ===================================================
        // إضافة عملاء وموردين
        // ===================================================
        private async Task<AgentResponse> StartAddCustomerAsync(
            ConversationSession session, IntentResult intent)
        {
            if (intent.Entities.TryGetValue("name", out var name) &&
                intent.Entities.TryGetValue("phone", out var phone))
            {
                var customer = await _parties.AddCustomerAsync(new CustomerDto
                {
                    Name  = name,
                    Phone = phone
                });
                return Reply(
                    $"✅ **تمت إضافة العميل بنجاح!**\n" +
                    $"👤 الاسم: {customer.Name}\n📱 الهاتف: {customer.Phone}\n🆔 رقم العميل: {customer.Id}");
            }

            session.PendingAction = "adding_customer";
            session.TempData["step"] = "name";

            return Reply(
                "👤 **إضافة عميل جديد**\nما اسم العميل؟",
                quickReplies: new[] { ("إلغاء","إلغاء") });
        }

        private async Task<AgentResponse> StartAddSupplierAsync(
            ConversationSession session, IntentResult intent)
        {
            if (intent.Entities.TryGetValue("name", out var name))
            {
                var supplier = await _parties.AddSupplierAsync(new SupplierDto { Name = name,
                    Phone = intent.Entities.GetValueOrDefault("phone") });
                return Reply($"✅ **تمت إضافة المورد:** {supplier.Name} (رقم {supplier.Id})");
            }

            session.PendingAction = "adding_supplier";
            session.TempData["step"] = "name";
            return Reply("🏭 **إضافة مورد جديد**\nما اسم المورد؟");
        }

        // ===================================================
        // التقارير
        // ===================================================
        private async Task<AgentResponse> GetDailySummaryAsync(IntentResult intent)
        {
            var date    = intent.Entities.TryGetValue("date", out var d)
                        ? ParseDate(d) : DateTime.Today;
            var summary = await _accounting.GetDailySummaryAsync(date);

            return Reply(
                $"📊 **ملخص يوم {date:dd/MM/yyyy}**\n\n" +
                $"💚 المبيعات:    **{summary.TotalSales:N2} ج.م** ({summary.SalesCount} فاتورة)\n" +
                $"🔴 المشتريات:  **{summary.TotalPurchases:N2} ج.م** ({summary.PurchaseCount} فاتورة)\n" +
                $"📈 إجمالي الأرباح: **{summary.GrossProfit:N2} ج.م**\n" +
                $"💰 الرصيد النقدي: **{summary.CashBalance:N2} ج.م**\n" +
                $"📥 ذمم مدينة: {summary.TotalReceivables:N2} | 📤 ذمم دائنة: {summary.TotalPayables:N2}",
                quickReplies: new[] {("كشف حساب عميل","كشف حساب"), ("ميزان المراجعة","ميزان المراجعة")});
        }

        private async Task<AgentResponse> GetTrialBalanceAsync()
        {
            var balance = await _accounting.GetTrialBalanceAsync();
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("📋 **ميزان المراجعة**\n");
            sb.AppendLine("```");
            sb.AppendLine($"{"الحساب",-25} {"مدين",12} {"دائن",12}");
            sb.AppendLine(new string('-', 51));
            foreach (var line in balance)
                sb.AppendLine($"{line.AccountName,-25} {line.Debit,12:N2} {line.Credit,12:N2}");
            sb.AppendLine(new string('-', 51));
            sb.AppendLine($"{"الإجمالي",-25} {balance.Sum(l=>l.Debit),12:N2} {balance.Sum(l=>l.Credit),12:N2}");
            sb.AppendLine("```");
            return Reply(sb.ToString());
        }

        private async Task<AgentResponse> SearchCustomerAsync(IntentResult intent, string text)
        {
            var query    = intent.Entities.GetValueOrDefault("name", text.Replace("ابحث", "").Trim());
            var results  = await _parties.SearchCustomersAsync(query);
            if (!results.Any()) return Reply($"❌ لا يوجد عميل باسم \"{query}\"");

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"🔍 نتائج البحث عن \"{query}\":\n");
            foreach (var c in results.Take(5))
                sb.AppendLine($"👤 **{c.Name}** | 📱 {c.Phone ?? "—"} | رصيد: {c.Balance:N2} ج.م");
            return Reply(sb.ToString());
        }

        private async Task<AgentResponse> GetCustomerBalanceAsync(IntentResult intent, string text)
        {
            var name     = intent.Entities.GetValueOrDefault("name", "");
            if (string.IsNullOrEmpty(name)) return Reply("اذكر اسم العميل. مثال: `رصيد العميل محمد أحمد`");
            var customer = await _parties.FindCustomerByNameAsync(name);
            if (customer == null) return Reply($"❌ لم أجد العميل \"{name}\"");

            var sign = customer.Balance > 0 ? "له علينا" : "عليه لنا";
            return Reply(
                $"👤 **{customer.Name}**\n📱 {customer.Phone ?? "—"}\n" +
                $"💰 الرصيد: **{Math.Abs(customer.Balance):N2} ج.م** ({sign})",
                quickReplies: new[] { ("كشف حسابه","كشف حساب"), ("تسجيل تحصيل","تحصيل") });
        }

        private async Task<AgentResponse> GetCustomerStatementAsync(IntentResult intent, string text)
        {
            var name = intent.Entities.GetValueOrDefault("name", "");
            if (string.IsNullOrEmpty(name)) return Reply("اذكر اسم العميل لعرض كشف حسابه.");
            var customer = await _parties.FindCustomerByNameAsync(name);
            if (customer == null) return Reply($"❌ لم أجد \"{name}\"");
            var stmt = await _accounting.GetCustomerStatementAsync(customer.Id, DateTime.Now.AddMonths(-1), DateTime.Now);

            var sb = new System.Text.StringBuilder();
            sb.AppendLine($"📄 **كشف حساب: {customer.Name}**\n");
            sb.AppendLine("```");
            sb.AppendLine($"{"التاريخ",10}  {"البيان",-20} {"مدين",10} {"دائن",10} {"رصيد",10}");
            foreach (var l in stmt.Lines.TakeLast(15))
                sb.AppendLine($"{l.Date:dd/MM/yy}  {l.Description,-20} {l.Debit,10:N2} {l.Credit,10:N2} {l.Balance,10:N2}");
            sb.AppendLine($"\nالرصيد الحالي: {stmt.ClosingBal:N2} ج.م");
            sb.AppendLine("```");
            return Reply(sb.ToString());
        }

        private async Task<AgentResponse> GetTopProductsAsync()
        {
            var products = await _parties.GetTopProductsAsync(10);
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("🏆 **أكثر المنتجات مبيعاً:**\n");
            int rank = 1;
            foreach (var p in products)
                sb.AppendLine($"{rank++}. {p.Name} — {p.Stock:N0} وحدة مباعة");
            return Reply(sb.ToString());
        }

        private async Task<AgentResponse> CheckStockAsync(IntentResult intent, string text)
        {
            var query = intent.Entities.GetValueOrDefault("product", text);
            var stock = await _parties.GetStockInfoAsync(query);
            return Reply(stock);
        }

        private async Task<AgentResponse> GetLowStockAsync()
        {
            var items = await _parties.GetLowStockItemsAsync();
            if (!items.Any()) return Reply("✅ جميع المنتجات فوق الحد الأدنى للمخزون.");
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("⚠️ **منتجات تحتاج لإعادة تخزين:**\n");
            foreach (var item in items)
                sb.AppendLine($"• {item.Name}: متبقي {item.Stock} فقط (باركود: {item.Barcode ?? "—"})");
            return Reply(sb.ToString());
        }

        private async Task<AgentResponse> RecordPaymentAsync(IntentResult intent, string text)
        {
            if (!intent.Entities.TryGetValue("price", out var amtStr) || !decimal.TryParse(amtStr, out var amount))
                return Reply("كم المبلغ المحصّل؟ مثال: `تحصيل من محمد 500`");
            var name = intent.Entities.GetValueOrDefault("name", "");
            var customer = string.IsNullOrEmpty(name) ? null : await _parties.FindCustomerByNameAsync(name);
            var result = await _accounting.RecordCollectionAsync(customer?.Id ?? 0, amount,
                $"تحصيل من {(customer?.Name ?? "عميل")}");
            return Reply(result.Message);
        }

        private async Task<AgentResponse> RecordExpenseAsync(IntentResult intent, string text)
        {
            if (!intent.Entities.TryGetValue("price", out var amtStr) || !decimal.TryParse(amtStr, out var amount))
                return Reply("كم قيمة المصروف؟ مثال: `دفعت إيجار 2000`");
            var result = await _accounting.RecordExpenseAsync("6010", "مصروفات عمومية", amount, text);
            return Reply(result.Message);
        }

        // ===================================================
        // معالجة الإجراء المعلّق
        // ===================================================
        private async Task<AgentResponse> HandlePendingActionAsync(
            ConversationSession session, string text)
        {
            return session.PendingAction switch
            {
                "building_sales_invoice" or
                "building_purchase_invoice" => await HandleInvoiceFlowAsync(session, text),
                "pos_active"               => await HandlePOSFlowAsync(session, text),
                "adding_customer"          => await HandleAddCustomerFlowAsync(session, text),
                "adding_supplier"          => await HandleAddSupplierFlowAsync(session, text),
                _                          => Reply("⚠️ حالة غير معروفة. اكتب **\"إلغاء\"** للبدء من جديد.")
            };
        }

        private async Task<AgentResponse> HandleInvoiceFlowAsync(ConversationSession session, string text)
        {
            var intent = _nlp.Detect(text);
            if (intent.Intent == AgentIntent.ConfirmInvoice) return await ConfirmInvoiceAsync(session);
            if (intent.Intent == AgentIntent.CancelInvoice)  return CancelPendingAction(session);
            if (intent.Intent == AgentIntent.AddItemToInvoice) return await AddItemToInvoiceAsync(session, intent, text);

            // محاولة استخراج بند مباشرة من النص
            return await AddItemToInvoiceAsync(session, intent, text);
        }

        private async Task<AgentResponse> HandlePOSFlowAsync(ConversationSession session, string text)
        {
            var intent = _nlp.Detect(text);
            var lower  = text.ToLower();

            if (lower.Contains("ادفع") || lower.Contains("الحساب") || lower.Contains("checkout"))
                return await CheckoutPOSAsync(session, intent);

            if (lower.Contains("عرض") || lower.Contains("الطلب"))
                return Reply(_pos.GetCartSummary(session.POSCart ?? new()));

            if (lower.Contains("مسح") || lower.Contains("جديد"))
                return ClearPOSCart(session);

            if (lower == "الخروج" || lower == "خروج")
            {
                session.POSCart = null;
                session.PendingAction = null;
                return Reply("👋 تم الخروج من وضع POS.", quickReplies: new[] { ("فاتورة بيع","فاتورة بيع"), ("ملخص اليوم","ملخص اليوم") });
            }

            return await AddToPOSAsync(session, intent, text);
        }

        private async Task<AgentResponse> HandleAddCustomerFlowAsync(ConversationSession session, string text)
        {
            session.TempData.TryGetValue("step", out var step);

            if (step == "name")
            {
                session.TempData["customer_name"] = text.Trim();
                session.TempData["step"] = "phone";
                return Reply($"✅ الاسم: **{text}**\nما رقم هاتفه؟ (أو اكتب \"تخطي\")");
            }
            if (step == "phone")
            {
                session.TempData["customer_phone"] = text == "تخطي" ? "" : text.Trim();
                var customer = await _parties.AddCustomerAsync(new CustomerDto
                {
                    Name  = session.TempData.GetValueOrDefault("customer_name", ""),
                    Phone = session.TempData.GetValueOrDefault("customer_phone")
                });
                session.TempData.Clear();
                session.PendingAction = null;
                return Reply($"✅ **تمت إضافة العميل:**\n👤 {customer.Name}\n📱 {customer.Phone ?? "—"}\n🆔 رقم: {customer.Id}");
            }

            return Reply("أرسل اسم العميل.");
        }

        private async Task<AgentResponse> HandleAddSupplierFlowAsync(ConversationSession session, string text)
        {
            session.TempData.TryGetValue("step", out var step);
            if (step == "name")
            {
                session.TempData["supplier_name"] = text;
                session.TempData["step"] = "phone";
                return Reply($"✅ اسم المورد: **{text}**\nرقم هاتفه؟ (أو \"تخطي\")");
            }
            if (step == "phone")
            {
                var supplier = await _parties.AddSupplierAsync(new SupplierDto
                {
                    Name  = session.TempData.GetValueOrDefault("supplier_name", ""),
                    Phone = text == "تخطي" ? null : text
                });
                session.TempData.Clear();
                session.PendingAction = null;
                return Reply($"✅ **تمت إضافة المورد:** {supplier.Name} (رقم {supplier.Id})");
            }
            return Reply("أرسل اسم المورد.");
        }

        // ===================================================
        // شاشة المساعدة
        // ===================================================
        private AgentResponse ShowHelp() => Reply(
            "🤖 **الوكيل المحاسبي الذكي — الأوامر المتاحة:**\n\n" +
            "**📋 الفواتير:**\n" +
            "• `فاتورة بيع` — إنشاء فاتورة مبيعات\n" +
            "• `فاتورة شراء` — إنشاء فاتورة مشتريات\n" +
            "• `صورة فاتورة` — قراءة فاتورة من صورة\n\n" +
            "**🏪 نقطة البيع:**\n" +
            "• `pos` أو `بيع مباشر` — تفعيل وضع الكاشير\n" +
            "• `باركود [رقم]` — إضافة صنف بالباركود\n\n" +
            "**👥 العملاء والموردين:**\n" +
            "• `عميل جديد` | `مورد جديد`\n" +
            "• `رصيد العميل [الاسم]`\n" +
            "• `كشف حساب [اسم العميل]`\n\n" +
            "**📊 التقارير:**\n" +
            "• `ملخص اليوم` | `ميزان المراجعة`\n" +
            "• `مخزون منخفض` | `أكثر المنتجات مبيعاً`\n\n" +
            "**💰 المدفوعات:**\n" +
            "• `تحصيل من [اسم] [مبلغ]`\n" +
            "• `مصروف [الوصف] [المبلغ]`",
            quickReplies: new[]
            {
                ("فاتورة بيع","فاتورة بيع"), ("POS","pos"),
                ("ملخص اليوم","ملخص اليوم"), ("مخزون منخفض","مخزون منخفض")
            });

        // ===================================================
        // دوال مساعدة
        // ===================================================
        private AgentResponse CancelPendingAction(ConversationSession session)
        {
            session.PendingAction  = null;
            session.PendingInvoice = null;
            session.TempData.Clear();
            return Reply("✅ تم الإلغاء. كيف يمكنني مساعدتك؟",
                quickReplies: new[] { ("مساعدة","مساعدة"), ("فاتورة بيع","فاتورة بيع"), ("POS","pos") });
        }

        private AgentResponse HandleUnknown(string text)
        {
            if (text.Length < 3) return Reply("كيف يمكنني مساعدتك؟ اكتب **\"مساعدة\"** لعرض الأوامر.");
            return Reply(
                $"لم أفهم طلبك بوضوح. هل تريد:\n" +
                "• **فاتورة بيع** أو **فاتورة شراء**؟\n" +
                "• **بيع مباشر (POS)**؟\n" +
                "• **تقرير** أو **إحصائيات**؟\n\n" +
                "اكتب **\"مساعدة\"** لعرض جميع الأوامر.",
                quickReplies: new[] { ("مساعدة","مساعدة"), ("فاتورة بيع","فاتورة بيع"), ("POS","pos") });
        }

        private string FormatInvoiceLines(CreateInvoiceRequest req)
        {
            if (!req.Lines.Any()) return "_لا توجد أصناف بعد_";
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("```");
            foreach (var l in req.Lines)
                sb.AppendLine($"{l.ProductName,-20} {l.Quantity} × {l.UnitPrice:N2} = {l.LineTotal:N2}");
            sb.AppendLine($"{"الإجمالي",-20} {req.Total:N2} ج.م");
            sb.AppendLine("```");
            return sb.ToString();
        }

        private string FormatJournal(List<JournalLine> journal)
        {
            var sb = new System.Text.StringBuilder();
            sb.AppendLine("```");
            foreach (var j in journal)
            {
                if (j.Debit  > 0) sb.AppendLine($"من ح/ {j.AccountName,-25} {j.Debit:N2}");
                if (j.Credit > 0) sb.AppendLine($"  إلى ح/ {j.AccountName,-23} {j.Credit:N2}");
            }
            sb.AppendLine("```");
            return sb.ToString();
        }

        private string ExtractAfterKeyword(string text, string[] keywords)
        {
            foreach (var kw in keywords)
            {
                var idx = text.IndexOf(kw, StringComparison.OrdinalIgnoreCase);
                if (idx >= 0)
                {
                    var after = text[(idx + kw.Length)..].Trim();
                    if (!string.IsNullOrEmpty(after)) return after.Split(' ')[0];
                }
            }
            return text.Trim();
        }

        private DateTime ParseDate(string d)
        {
            if (DateTime.TryParse(d, out var dt)) return dt;
            return DateTime.Today;
        }

        private AgentResponse Reply(string msg,
            (string Label, string Value)[]? quickReplies = null) =>
            new()
            {
                Message = msg,
                QuickReplies = quickReplies?.Select(q => new QuickReply(q.Label, q.Value)).ToList()
                               ?? new List<QuickReply>()
            };

        private AgentResponse Error(string msg) => new() { Message = msg, IsError = true };
    }

    // ===================================================
    // Session Store - خفيف، بدون DB
    // ===================================================
    public class SessionStore
    {
        private readonly Dictionary<string, ConversationSession> _store = new();
        private readonly System.Timers.Timer _cleanup;

        public SessionStore()
        {
            _cleanup = new System.Timers.Timer(TimeSpan.FromMinutes(30).TotalMilliseconds);
            _cleanup.Elapsed += (_, _) => CleanExpired();
            _cleanup.Start();
        }

        public ConversationSession GetOrCreate(string id, string channel, long? telegramId = null)
        {
            if (!_store.TryGetValue(id, out var session))
            {
                session = new ConversationSession { SessionId = id, Channel = channel, TelegramChatId = telegramId };
                _store[id] = session;
            }
            return session;
        }

        public ConversationSession? GetByTelegram(long chatId) =>
            _store.Values.FirstOrDefault(s => s.TelegramChatId == chatId);

        private void CleanExpired()
        {
            var expiry = DateTime.Now.AddHours(-2);
            var toRemove = _store.Where(kv => kv.Value.LastActivity < expiry)
                                 .Select(kv => kv.Key).ToList();
            foreach (var k in toRemove) _store.Remove(k);
        }
    }

    // واجهة استعلامات الأطراف والمنتجات
    public interface IPartyRepository
    {
        Task<CustomerDto?> FindCustomerByNameAsync(string name);
        Task<SupplierDto?> FindSupplierByNameAsync(string name);
        Task<List<CustomerDto>> SearchCustomersAsync(string query);
        Task<CustomerDto> AddCustomerAsync(CustomerDto customer);
        Task<SupplierDto> AddSupplierAsync(SupplierDto supplier);
        Task<List<ProductLookup>> GetTopProductsAsync(int count = 10);
        Task<string> GetStockInfoAsync(string query);
        Task<List<ProductLookup>> GetLowStockItemsAsync(decimal threshold = 10);
    }

    // واجهة خدمة قراءة الفواتير
    public class InvoiceParserService
    {
        public async Task<ParsedInvoice?> ParseFromBase64Async(string imageBase64)
        {
            // يمكن ربطها بـ Tesseract OCR محلي أو Azure Vision
            // هنا نعيد نتيجة تجريبية
            await Task.Delay(10);
            return new ParsedInvoice
            {
                SupplierName = "مورد من الصورة",
                Date         = DateTime.Today,
                Confidence   = 0.87f,
                Lines        = new List<InvoiceLineDto>(),
                RawText      = "[OCR result]"
            };
        }
    }
}
