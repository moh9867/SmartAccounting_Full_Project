using System.Text.RegularExpressions;
using SmartAccountingAgent.Models;

namespace SmartAccountingAgent.Agent.NLP
{
    // ===================================================
    // محرك فهم اللغة الطبيعية - خفيف 100% بدون API خارجي
    // يعمل بدون إنترنت وبدون استهلاك RAM
    // ===================================================
    public class IntentDetector
    {
        // قاموس النوايا بالعربية والإنجليزية
        private static readonly List<(AgentIntent Intent, string[] Keywords, float Weight)> _rules = new()
        {
            // ===== مبيعات =====
            (AgentIntent.CreateSalesInvoice,
             new[]{"فاتورة بيع","بيع","بيعت","سوّق","باع","أضف فاتورة","فاتورة مبيعات","بياعة","sales invoice","sell"},
             0.9f),
            (AgentIntent.AddItemToInvoice,
             new[]{"أضف","اضف","ضيف","صنف","منتج","بند","قلم","item","add product","زود"},
             0.85f),
            (AgentIntent.ConfirmInvoice,
             new[]{"تأكيد","أكد","احفظ","ثبّت","خلص","سجل","confirm","save","ok","موافق","نعم","أيوه","ايوا"},
             0.9f),
            (AgentIntent.CancelInvoice,
             new[]{"إلغاء","الغي","ألغ","cancel","لا","مش عارف","امسح الفاتورة"},
             0.85f),

            // ===== مشتريات =====
            (AgentIntent.CreatePurchaseInvoice,
             new[]{"فاتورة شراء","مشتريات","اشتريت","شرا","شريت","purchase","فاتورة مورد","استلمت بضاعة"},
             0.9f),
            (AgentIntent.ReadInvoiceFromImage,
             new[]{"صورة فاتورة","اقرأ الفاتورة","حلّل الفاتورة","scan","ocr","صورة","فوتو","photo","الصورة دي"},
             0.85f),

            // ===== POS =====
            (AgentIntent.StartPOS,
             new[]{"نقطة البيع","pos","كاشير","كاشر","بيع مباشر","بدأ بيع","ابدأ"},
             0.9f),
            (AgentIntent.AddToPOSCart,
             new[]{"أضف للعربة","ضيف","باركود","barcode","scan item","أضف صنف","جيب"},
             0.8f),
            (AgentIntent.CheckoutPOS,
             new[]{"ادفع","checkout","خلّص البيع","إتمام","print","اطبع","الحساب","كم الحساب","الإجمالي"},
             0.9f),
            (AgentIntent.ClearPOSCart,
             new[]{"امسح الطلب","مسح","clear cart","جديد","طلب جديد","ابدأ من جديد"},
             0.85f),

            // ===== عملاء =====
            (AgentIntent.AddCustomer,
             new[]{"عميل جديد","أضف عميل","سجّل عميل","زبون جديد","add customer","new customer"},
             0.9f),
            (AgentIntent.AddSupplier,
             new[]{"مورد جديد","أضف مورد","سجل مورد","add supplier"},
             0.9f),
            (AgentIntent.SearchCustomer,
             new[]{"ابحث عن","بحث","عميل اسمه","زبون","فين","find customer","search"},
             0.8f),
            (AgentIntent.GetCustomerBalance,
             new[]{"رصيد عميل","حساب عميل","ديون","مديونية","ايه اللي عليه","كم الرصيد","balance"},
             0.9f),

            // ===== تقارير =====
            (AgentIntent.GetDailySummary,
             new[]{"ملخص اليوم","تقرير اليوم","إيه اللي حصل","مبيعات اليوم","daily","اليومية","النهاردة"},
             0.9f),
            (AgentIntent.GetCustomerStatement,
             new[]{"كشف حساب","تقرير عميل","statement","حركة العميل","معاملات"},
             0.9f),
            (AgentIntent.GetTrialBalance,
             new[]{"ميزان المراجعة","trial balance","الميزان","المراجعة"},
             0.95f),
            (AgentIntent.GetTopProducts,
             new[]{"أكثر المنتجات","الأكثر مبيعاً","top products","الأعلى مبيعات","منتجات ناجحة"},
             0.85f),

            // ===== مخزون =====
            (AgentIntent.CheckStock,
             new[]{"المخزون","رصيد المخزن","stock","كمية","كام","الكمية","متوفر"},
             0.85f),
            (AgentIntent.GetLowStock,
             new[]{"مخزون منخفض","على وشك ينتهي","low stock","هينتهي","نفذ","تحذيرات"},
             0.9f),

            // ===== مدفوعات =====
            (AgentIntent.RecordPayment,
             new[]{"تحصيل","استلمت","قبض","سدّد","payment","collect","عميل دفع"},
             0.9f),
            (AgentIntent.RecordExpense,
             new[]{"مصروف","دفعت","نفقة","expense","فاتورة كهرباء","إيجار","رواتب"},
             0.9f),

            // ===== نظام =====
            (AgentIntent.Help,
             new[]{"مساعدة","help","ايه اللي تقدر","وظائفك","إيه اللي بتعمله","أوامر"},
             0.95f),
            (AgentIntent.CancelAction,
             new[]{"إلغاء","ألغ","لا مش هاعمل","cancel","رجّع","اخرج"},
             0.9f),
        };

        // ===================================================
        // الكشف الرئيسي عن النية
        // ===================================================
        public IntentResult Detect(string text)
        {
            var normalized = NormalizeArabic(text.ToLower().Trim());

            var bestMatch = (Intent: AgentIntent.Unknown, Score: 0f);
            var entities  = new Dictionary<string, string>();

            foreach (var (intent, keywords, weight) in _rules)
            {
                float score = 0;
                foreach (var kw in keywords)
                {
                    if (normalized.Contains(kw.ToLower()))
                    {
                        var kwScore = weight * ((float)kw.Length / normalized.Length + 0.5f);
                        score = Math.Max(score, kwScore);
                    }
                }
                if (score > bestMatch.Score)
                    bestMatch = (intent, score);
            }

            // استخراج الكيانات
            entities = ExtractEntities(normalized);

            return new IntentResult
            {
                Intent     = bestMatch.Score > 0.3f ? bestMatch.Intent : AgentIntent.Unknown,
                Confidence = Math.Min(bestMatch.Score, 1f),
                Entities   = entities
            };
        }

        // ===================================================
        // استخراج الكيانات (أسماء، أرقام، تواريخ)
        // ===================================================
        private Dictionary<string, string> ExtractEntities(string text)
        {
            var entities = new Dictionary<string, string>();

            // استخراج الأرقام (كميات وأسعار)
            var numbers = Regex.Matches(text, @"\d+(?:\.\d+)?");
            if (numbers.Count >= 1) entities["quantity"] = numbers[0].Value;
            if (numbers.Count >= 2) entities["price"]    = numbers[1].Value;
            if (numbers.Count >= 3) entities["discount"] = numbers[2].Value;

            // استخراج الاسم بعد "اسمه" أو "عميل" أو "مورد"
            var nameMatch = Regex.Match(text, @"(?:اسمه|العميل|المورد|اسم)\s+([^\d\n,،]+?)(?:\s|$|,|،)");
            if (nameMatch.Success) entities["name"] = nameMatch.Groups[1].Value.Trim();

            // استخراج رقم الهاتف
            var phoneMatch = Regex.Match(text, @"(?:01[0-9]{9}|0[2-9][0-9]{8,9})");
            if (phoneMatch.Success) entities["phone"] = phoneMatch.Value;

            // استخراج التاريخ
            var dateMatch = Regex.Match(text, @"\d{1,2}[\/\-]\d{1,2}(?:[\/\-]\d{2,4})?");
            if (dateMatch.Success) entities["date"] = dateMatch.Value;

            // استخراج اسم المنتج: "صنف X" أو "منتج X"
            var productMatch = Regex.Match(text, @"(?:صنف|منتج|بضاعة|سلعة)\s+([^\d\n,،]{2,30})");
            if (productMatch.Success) entities["product"] = productMatch.Groups[1].Value.Trim();

            // استخراج الباركود
            var barcodeMatch = Regex.Match(text, @"\b\d{8,13}\b");
            if (barcodeMatch.Success) entities["barcode"] = barcodeMatch.Value;

            return entities;
        }

        // ===================================================
        // تطبيع النص العربي (إزالة التشكيل، توحيد الأحرف)
        // ===================================================
        private string NormalizeArabic(string text)
        {
            // إزالة التشكيل
            text = Regex.Replace(text, @"[\u064B-\u065F]", "");
            // توحيد الألف
            text = text.Replace("أ","ا").Replace("إ","ا").Replace("آ","ا");
            // توحيد الياء والواو
            text = text.Replace("ى","ي").Replace("ة","ه");
            return text;
        }
    }
}
