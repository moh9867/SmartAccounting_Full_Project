// ===================================================
// Smart Accounting Agent - JS Helpers
// خفيف 100% - بدون jQuery أو مكتبات ثقيلة
// ===================================================

// تمرير للأسفل
window.scrollToBottom = (elementId) => {
    const el = document.getElementById(elementId);
    if (el) el.scrollTop = el.scrollHeight;
};

// التركيز على عنصر
window.focusElement = (element) => {
    if (element) { element.focus(); }
};

// النقر على عنصر (لتشغيل input file)
window.triggerClick = (elementId) => {
    const el = document.getElementById(elementId);
    if (el) el.click();
};

// ساعة نقطة البيع
window.startClock = (elementId) => {
    const update = () => {
        const el = document.getElementById(elementId);
        if (el) el.textContent = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });
    };
    update();
    setInterval(update, 30000);
};

// إشعار Toast خفيف
window.showToast = (message, type = 'success') => {
    const old = document.querySelector('.toast');
    if (old) old.remove();

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity .3s';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
};

// طباعة الإيصال (بدون نافذة طباعة كاملة)
window.printReceipt = (receiptText) => {
    const win = window.open('', '_blank', 'width=300,height=600');
    if (!win) return;
    win.document.write(`
        <html dir="rtl">
        <head>
            <title>إيصال</title>
            <style>
                body { font-family: 'Courier New', monospace; font-size: 13px; padding: 10px; direction: rtl; }
                pre  { white-space: pre-wrap; word-break: break-word; }
            </style>
        </head>
        <body>
            <pre>${receiptText}</pre>
            <script>window.onload = () => { window.print(); window.close(); }<\/script>
        </body>
        </html>
    `);
    win.document.close();
};

// إصلاح ارتفاع textarea تلقائياً
document.addEventListener('input', (e) => {
    if (e.target.classList.contains('chat-input')) {
        e.target.style.height = 'auto';
        e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px';
    }
});
