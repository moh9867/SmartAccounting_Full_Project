#!/usr/bin/env bash
# ===================================================
# سكريبت تثبيت Tesseract OCR (عربي + إنجليزي)
# شغّله مرة واحدة قبل تشغيل المشروع
# ===================================================

set -e
TESSDATA_DIR="$(pwd)/tessdata"
mkdir -p "$TESSDATA_DIR"

echo "📥 تحميل ملفات اللغة لـ Tesseract..."

BASE_URL="https://github.com/tesseract-ocr/tessdata_best/raw/main"

# العربية (أفضل نموذج للفواتير)
if [ ! -f "$TESSDATA_DIR/ara.traineddata" ]; then
    echo "  ← ara.traineddata"
    curl -L -o "$TESSDATA_DIR/ara.traineddata" "$BASE_URL/ara.traineddata"
fi

# الإنجليزية (للفواتير المختلطة)
if [ ! -f "$TESSDATA_DIR/eng.traineddata" ]; then
    echo "  ← eng.traineddata"
    curl -L -o "$TESSDATA_DIR/eng.traineddata" "$BASE_URL/eng.traineddata"
fi

echo "✅ tessdata جاهز في: $TESSDATA_DIR"
echo ""
echo "الخطوة التالية: تحديث appsettings.json"
echo '  "InvoiceParser": {'
echo '    "TesseractDataPath": "'$TESSDATA_DIR'",'
echo '    "Languages": "ara+eng"'
echo '  }'
