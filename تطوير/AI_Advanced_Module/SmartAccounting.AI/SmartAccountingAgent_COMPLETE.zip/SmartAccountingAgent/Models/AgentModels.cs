namespace SmartAccountingAgent.Models
{
    // ===================================================
    // نماذج البيانات الكاملة - محسّنة للأجهزة الضعيفة
    // ===================================================

    #region Chat & Session

    public record ChatMessage(string Role, string Content, DateTime At = default)
    {
        public DateTime At { get; init; } = At == default ? DateTime.Now : At;
    }

    public class AgentRequest
    {
        public string SessionId   { get; set; } = string.Empty;
        public string UserMessage { get; set; } = string.Empty;
        public string Channel     { get; set; } = "web"; // web | telegram | pos
        public long?  TelegramChatId { get; set; }
        public string? ImageBase64 { get; set; } // لقراءة الفواتير
    }

    public class AgentResponse
    {
        public string  Message           { get; set; } = string.Empty;
        public string? ActionTaken       { get; set; }
        public object? Data              { get; set; }
        public bool    NeedsConfirmation { get; set; }
        public string? ConfirmationKey   { get; set; }
        public List<QuickReply> QuickReplies { get; set; } = new();
        public AgentResponseType Type    { get; set; } = AgentResponseType.Text;
        public bool IsError              { get; set; }
    }

    public enum AgentResponseType { Text, InvoicePreview, POSReceipt, Report, CustomerCard }
    public record QuickReply(string Label, string Value);

    // جلسة المحادثة — آخر 8 رسائل فقط في الذاكرة
    public class ConversationSession
    {
        public string  SessionId      { get; set; } = Guid.NewGuid().ToString("N")[..10];
        public string  Channel        { get; set; } = "web";
        public long?   TelegramChatId { get; set; }
        public DateTime LastActivity  { get; set; } = DateTime.Now;

        // Context خفيف
        public string?               PendingAction  { get; set; }
        public CreateInvoiceRequest? PendingInvoice { get; set; }
        public POSCartState?         POSCart        { get; set; }
        public Dictionary<string, string> TempData  { get; set; } = new();

        private readonly List<ChatMessage> _messages = new();
        public IReadOnlyList<ChatMessage> Messages => _messages;

        public void AddMessage(string role, string content)
        {
            _messages.Add(new ChatMessage(role, content));
            if (_messages.Count > 8) _messages.RemoveAt(0); // حد الذاكرة
        }

        public string GetHistoryText() =>
            string.Join("\n", _messages.TakeLast(6).Select(m => $"{m.Role}: {m.Content}"));
    }

    #endregion

    #region Customers & Suppliers

    public class CustomerDto
    {
        public int     Id         { get; set; }
        public string  Name       { get; set; } = string.Empty;
        public string? Phone      { get; set; }
        public string? Address    { get; set; }
        public string? TaxNumber  { get; set; }
        public string? Email      { get; set; }
        public decimal Balance    { get; set; }
        public string  BalanceType => Balance >= 0 ? "له" : "عليه";
        public DateTime CreatedAt  { get; set; } = DateTime.Now;
    }

    public class SupplierDto
    {
        public int     Id        { get; set; }
        public string  Name      { get; set; } = string.Empty;
        public string? Phone     { get; set; }
        public string? Address   { get; set; }
        public string? TaxNumber { get; set; }
        public string? Email     { get; set; }
        public decimal Balance   { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    #endregion

    #region Invoices

    public class InvoiceLineDto
    {
        public int?    ProductId   { get; set; }
        public string  ProductName { get; set; } = string.Empty;
        public string? ProductCode { get; set; }
        public decimal Quantity    { get; set; } = 1;
        public decimal UnitPrice   { get; set; }
        public decimal Discount    { get; set; } = 0; // نسبة مئوية
        public decimal LineTotal   => Math.Round(Quantity * UnitPrice * (1 - Discount / 100), 2);
    }

    public class CreateInvoiceRequest
    {
        public InvoiceType Type           { get; set; } = InvoiceType.Sales;
        public int?   CustomerId          { get; set; }
        public int?   SupplierId          { get; set; }
        public string PartyName           { get; set; } = string.Empty; // اسم العميل/المورد
        public List<InvoiceLineDto> Lines { get; set; } = new();
        public decimal DiscountPercent    { get; set; } = 0;
        public decimal TaxPercent         { get; set; } = 0; // 14 للضريبة المصرية
        public PaymentMethod Payment      { get; set; } = PaymentMethod.Cash;
        public decimal PaidAmount         { get; set; }
        public string? Notes              { get; set; }
        public DateTime Date              { get; set; } = DateTime.Today;

        // الحسابات
        public decimal Subtotal        => Lines.Sum(l => l.LineTotal);
        public decimal DiscountAmount  => Math.Round(Subtotal * DiscountPercent / 100, 2);
        public decimal AfterDiscount   => Subtotal - DiscountAmount;
        public decimal TaxAmount       => Math.Round(AfterDiscount * TaxPercent / 100, 2);
        public decimal Total           => AfterDiscount + TaxAmount;
        public decimal Remaining       => Total - PaidAmount;
    }

    public enum InvoiceType    { Sales, Purchase, SalesReturn, PurchaseReturn }
    public enum PaymentMethod  { Cash, Credit, Partial, BankTransfer }

    public class InvoiceResult
    {
        public int     Id            { get; set; }
        public string  InvoiceNumber { get; set; } = string.Empty;
        public decimal Subtotal      { get; set; }
        public decimal DiscountAmt   { get; set; }
        public decimal TaxAmount     { get; set; }
        public decimal Total         { get; set; }
        public decimal PaidAmount    { get; set; }
        public decimal Remaining     { get; set; }
        public List<JournalLine> JournalEntries { get; set; } = new();
        public string  ReceiptText   { get; set; } = string.Empty; // للطباعة
    }

    public class JournalLine
    {
        public string  AccountCode { get; set; } = string.Empty;
        public string  AccountName { get; set; } = string.Empty;
        public decimal Debit       { get; set; }
        public decimal Credit      { get; set; }
        public string  Note        { get; set; } = string.Empty;
    }

    // فاتورة مقروءة (من صورة أو نص)
    public class ParsedInvoice
    {
        public string? SupplierName   { get; set; }
        public string? InvoiceNumber  { get; set; }
        public DateTime? Date         { get; set; }
        public List<InvoiceLineDto> Lines { get; set; } = new();
        public decimal? TotalAmount   { get; set; }
        public decimal? TaxAmount     { get; set; }
        public float    Confidence    { get; set; }
        public string   RawText       { get; set; } = string.Empty;
    }

    #endregion

    #region POS (نقطة البيع)

    public class POSCartState
    {
        public List<POSCartItem> Items    { get; set; } = new();
        public string? CustomerName       { get; set; }
        public int?    CustomerId         { get; set; }
        public decimal DiscountPercent    { get; set; }
        public PaymentMethod Payment      { get; set; } = PaymentMethod.Cash;
        public decimal PaidAmount         { get; set; }

        public decimal Subtotal    => Items.Sum(i => i.LineTotal);
        public decimal DiscountAmt => Math.Round(Subtotal * DiscountPercent / 100, 2);
        public decimal Total       => Subtotal - DiscountAmt;
        public decimal Change      => PaidAmount > Total ? PaidAmount - Total : 0;
        public decimal Remaining   => Total > PaidAmount ? Total - PaidAmount : 0;

        public bool IsEmpty => !Items.Any();
    }

    public class POSCartItem
    {
        public int     ProductId   { get; set; }
        public string  ProductName { get; set; } = string.Empty;
        public string? Barcode     { get; set; }
        public decimal Quantity    { get; set; } = 1;
        public decimal UnitPrice   { get; set; }
        public decimal Discount    { get; set; }
        public decimal LineTotal   => Math.Round(Quantity * UnitPrice * (1 - Discount / 100), 2);
    }

    public class ProductLookup
    {
        public int     Id          { get; set; }
        public string  Name        { get; set; } = string.Empty;
        public string? Code        { get; set; }
        public string? Barcode     { get; set; }
        public decimal SalePrice   { get; set; }
        public decimal CostPrice   { get; set; }
        public decimal Stock       { get; set; }
        public bool    InStock     => Stock > 0;
    }

    #endregion

    #region Reports & Finance

    public class FinancialSummary
    {
        public decimal TotalSales       { get; set; }
        public decimal TotalPurchases   { get; set; }
        public decimal TotalReceivables { get; set; }
        public decimal TotalPayables    { get; set; }
        public decimal CashBalance      { get; set; }
        public decimal GrossProfit      { get; set; }
        public decimal NetProfit        { get; set; }
        public int     SalesCount       { get; set; }
        public int     PurchaseCount    { get; set; }
        public DateTime From            { get; set; }
        public DateTime To              { get; set; }
        public string PeriodLabel       => $"{From:dd/MM} - {To:dd/MM/yyyy}";
    }

    public class AccountStatement
    {
        public string  AccountCode  { get; set; } = string.Empty;
        public string  AccountName  { get; set; } = string.Empty;
        public decimal OpeningBal   { get; set; }
        public List<StatementLine> Lines { get; set; } = new();
        public decimal ClosingBal   => OpeningBal + Lines.Sum(l => l.Debit - l.Credit);
    }

    public class StatementLine
    {
        public DateTime Date        { get; set; }
        public string   Description { get; set; } = string.Empty;
        public decimal  Debit       { get; set; }
        public decimal  Credit      { get; set; }
        public decimal  Balance     { get; set; }
    }

    #endregion

    #region Intent Detection (NLU خفيف بدون AI API)

    public enum AgentIntent
    {
        Unknown,
        // مبيعات
        CreateSalesInvoice, AddItemToInvoice, ConfirmInvoice, CancelInvoice,
        // مشتريات
        CreatePurchaseInvoice, ReadInvoiceFromImage,
        // POS
        StartPOS, AddToPOSCart, RemoveFromPOSCart, CheckoutPOS, ClearPOSCart,
        // عملاء/موردين
        AddCustomer, AddSupplier, SearchCustomer, GetCustomerBalance,
        // تقارير
        GetDailySummary, GetCustomerStatement, GetTrialBalance, GetTopProducts,
        // مخزون
        CheckStock, GetLowStock,
        // مدفوعات
        RecordPayment, RecordExpense,
        // نظام
        Help, CancelAction
    }

    public class IntentResult
    {
        public AgentIntent Intent     { get; set; }
        public float       Confidence { get; set; }
        public Dictionary<string, string> Entities { get; set; } = new();
    }

    #endregion
}
