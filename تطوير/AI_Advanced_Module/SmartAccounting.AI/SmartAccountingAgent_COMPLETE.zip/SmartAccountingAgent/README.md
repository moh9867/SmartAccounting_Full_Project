# 🚀 دليل تشغيل الوكيل المحاسبي الذكي

## المتطلبات
- .NET 8 SDK  →  https://dotnet.microsoft.com/download
- لا يحتاج SQL Server (يعمل بـ SQLite افتراضياً)

---

## ⚡ تشغيل في 4 أوامر فقط

```bash
# 1. استعادة الحزم
dotnet restore

# 2. إنشاء Migrations لقاعدة البيانات
dotnet ef migrations add InitialCreate --project SmartAccountingAgent.csproj

# 3. تطبيق قاعدة البيانات (تلقائي عند أول تشغيل أيضاً)
dotnet ef database update

# 4. تشغيل التطبيق
dotnet run
```

ثم افتح: **http://localhost:5000**

---

## 🤖 تفعيل بوت تليجرام

في `appsettings.json`:
```json
{
  "Telegram": {
    "BotToken": "YOUR_BOT_TOKEN_FROM_@BotFather",
    "WebhookUrl": "",
    "AllowedChatIds": []
  }
}
```

**للحصول على التوكن:**
1. افتح تليجرام → ابحث عن `@BotFather`
2. أرسل `/newbot` واتبع الخطوات
3. انسخ التوكن في الإعدادات

---

## 🗄️ التبديل لـ SQL Server (شبكات)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=.;Database=SmartAccounting;Trusted_Connection=True;"
  }
}
```

---

## 📁 هيكل الملفات الكامل

```
SmartAccountingAgent/
├── Program.cs                          ✅ نقطة الدخول
├── appsettings.json                    ✅ الإعدادات
├── SmartAccountingAgent.csproj         ✅ الحزم
│
├── Models/
│   └── AgentModels.cs                  ✅ كل النماذج
│
├── Agent/
│   ├── NLP/IntentDetector.cs           ✅ فهم اللغة العربية
│   └── Core/AccountingAgent.cs         ✅ الوكيل الرئيسي
│
├── Services/
│   ├── Accounting/AccountingEngine.cs  ✅ المحرك المحاسبي
│   └── POS/POSService.cs              ✅ نقطة البيع
│
├── Data/
│   └── AccountingDbContext.cs          ✅ DB + Repositories
│
├── Extensions/
│   └── AgentServiceExtensions.cs      ✅ تسجيل DI
│
├── TelegramBot/
│   └── TelegramBotService.cs          ✅ بوت تليجرام
│
└── Blazor/
    ├── App.razor
    ├── Shared/MainLayout.razor         ✅ التصميم الرئيسي
    ├── Pages/
    │   ├── DashboardPage.razor         ✅ لوحة التحكم
    │   ├── ChatPage.razor              ✅ صفحة المحادثة
    │   └── POSPage.razor              ✅ نقطة البيع
    ├── Components/Chat/
    │   └── AgentChatWidget.razor      ✅ ودجت المحادثة
    └── wwwroot/
        ├── agent-styles.css            ✅ التصميم
        └── agent.js                    ✅ JavaScript
```

---

## 💬 أمثلة أوامر الوكيل

| تكتب | يفعل الوكيل |
|------|-------------|
| `فاتورة بيع` | يفتح فاتورة جديدة |
| `أضف سكر 5 كيلو بـ 32` | يضيف بنداً للفاتورة |
| `تأكيد` | يحفظ الفاتورة ويسجل القيود |
| `pos` | يدخل وضع الكاشير |
| `باركود 6221234560001` | يضيف صنفاً بالباركود |
| `ادفع 100` | يتمم البيع |
| `عميل جديد` | يضيف عميلاً |
| `ملخص اليوم` | يعرض إحصائيات اليوم |
| `رصيد العميل محمد` | يعرض رصيد العميل |
| `مخزون منخفض` | تحذيرات المخزون |
| صورة فاتورة 📷 | يقرأ الفاتورة تلقائياً |
