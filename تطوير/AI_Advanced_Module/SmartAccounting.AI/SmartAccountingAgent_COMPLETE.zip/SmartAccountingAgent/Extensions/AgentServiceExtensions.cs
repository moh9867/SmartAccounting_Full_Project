using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SmartAccountingAgent.Agent.Core;
using SmartAccountingAgent.Agent.NLP;
using SmartAccountingAgent.Data;
using SmartAccountingAgent.Services.Accounting;
using SmartAccountingAgent.Services.POS;
using SmartAccountingAgent.TelegramBot;
using Telegram.Bot;

namespace SmartAccountingAgent.Extensions
{
    // ===================================================
    // تسجيل كل خدمات الوكيل — سطر واحد في Program.cs
    //
    // الاستخدام:
    //   builder.Services.AddSmartAccountingAgent(builder.Configuration);
    // ===================================================
    public static class AgentServiceExtensions
    {
        public static IServiceCollection AddSmartAccountingAgent(
            this IServiceCollection services,
            IConfiguration config)
        {
            // ===== 1. قاعدة البيانات =====
            var connStr = config.GetConnectionString("DefaultConnection")
                       ?? "Data Source=SmartAccounting.db";

            if (connStr.Contains("Data Source") || connStr.EndsWith(".db"))
            {
                // SQLite — للأجهزة الضعيفة (بدون سيرفر)
                services.AddDbContext<SmartAccountingDbContext>(opt =>
                    opt.UseSqlite(connStr, b => b.MigrationsAssembly("SmartAccountingAgent"))
                       .EnableSensitiveDataLogging(false)
                       .UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking),
                    ServiceLifetime.Scoped);
            }
            else
            {
                // SQL Server — للشبكات والإنتاج
                services.AddDbContext<SmartAccountingDbContext>(opt =>
                    opt.UseSqlServer(connStr, b => b.MigrationsAssembly("SmartAccountingAgent"))
                       .EnableSensitiveDataLogging(false),
                    ServiceLifetime.Scoped);
            }

            // ===== 2. Repositories (Scoped = طلب جديد لكل request) =====
            services.AddScoped<IAccountingDb,      AccountingDbService>();
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IPartyRepository,   PartyRepository>();

            // ===== 3. Services (Scoped) =====
            services.AddScoped<AccountingEngine>();
            services.AddScoped<POSService>();
            services.AddScoped<InvoiceParserService>();

            // ===== 4. NLP (Singleton — خفيف ومشترك) =====
            services.AddSingleton<IntentDetector>();

            // ===== 5. Session Store (Singleton — يحتفظ بالجلسات في الذاكرة) =====
            services.AddSingleton<SessionStore>();

            // ===== 6. الوكيل الرئيسي (Scoped) =====
            services.AddScoped<AccountingAgent>();

            // ===== 7. بوت تليجرام (اختياري) =====
            var botToken = config["Telegram:BotToken"];
            if (!string.IsNullOrWhiteSpace(botToken))
            {
                services.AddSingleton<ITelegramBotClient>(
                    _ => new TelegramBotClient(botToken));

                services.AddSingleton(new TelegramBotConfig
                {
                    Token         = botToken,
                    WebhookUrl    = config["Telegram:WebhookUrl"],
                    AllowedChatIds = config.GetSection("Telegram:AllowedChatIds")
                                         .Get<List<long>>() ?? new()
                });

                // تشغيل البوت كـ Background Service
                services.AddHostedService<TelegramBotService>();
            }

            // ===== 8. CORS للـ API (إن وجدت) =====
            services.AddCors(opt => opt.AddPolicy("AgentPolicy", p =>
                p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

            return services;
        }

        // ===================================================
        // إنشاء قاعدة البيانات وتطبيق الـ Migrations تلقائياً
        // استدعِها مرة واحدة عند بدء التطبيق
        // ===================================================
        public static async Task InitializeDatabaseAsync(this IServiceProvider services)
        {
            using var scope  = services.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<SmartAccountingDbContext>();

            // تطبيق الـ migrations المعلّقة
            await db.Database.MigrateAsync();

            // بيانات تجريبية إن كانت القاعدة فارغة
            await SeedInitialDataAsync(db);
        }

        private static async Task SeedInitialDataAsync(SmartAccountingDbContext db)
        {
            if (await db.Products.AnyAsync()) return; // لا تكرر البذر

            // منتجات تجريبية
            db.Products.AddRange(
                new Data.AppProduct { Name="سكر",          Code="PRD-001", Barcode="6221234560001", SalePrice=32,  CostPrice=28,  Stock=500, MinStock=50 },
                new Data.AppProduct { Name="أرز مصري",     Code="PRD-002", Barcode="6221234560002", SalePrice=45,  CostPrice=38,  Stock=300, MinStock=50 },
                new Data.AppProduct { Name="زيت نباتي 1L", Code="PRD-003", Barcode="6221234560003", SalePrice=65,  CostPrice=55,  Stock=200, MinStock=30 },
                new Data.AppProduct { Name="دقيق",         Code="PRD-004", Barcode="6221234560004", SalePrice=28,  CostPrice=22,  Stock=400, MinStock=50 },
                new Data.AppProduct { Name="ملح طعام",     Code="PRD-005", Barcode="6221234560005", SalePrice=8,   CostPrice=5,   Stock=8,   MinStock=50 },
                new Data.AppProduct { Name="شاي أحمر",     Code="PRD-006", Barcode="6221234560006", SalePrice=55,  CostPrice=45,  Stock=150, MinStock=20 }
            );

            // عملاء تجريبيون
            db.Customers.AddRange(
                new Data.AppCustomer { Name="محمد أحمد",   Phone="01001234567", Balance=0   },
                new Data.AppCustomer { Name="شركة النور",  Phone="0225001234",  Balance=2500 },
                new Data.AppCustomer { Name="أحمد السيد",  Phone="01112345678", Balance=0   }
            );

            // موردون تجريبيون
            db.Suppliers.AddRange(
                new Data.AppSupplier { Name="شركة الأمل للتوريد", Phone="0223456789", Balance=0    },
                new Data.AppSupplier { Name="مصنع النيل",         Phone="0223334444", Balance=5000 }
            );

            await db.SaveChangesAsync();
        }
    }
}
