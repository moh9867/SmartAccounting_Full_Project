using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using SmartAccountingAgent.Agent.Core;
using SmartAccountingAgent.Data;
using SmartAccountingAgent.Services.Accounting;
using SmartAccountingAgent.Services.Invoice;
using SmartAccountingAgent.Services.POS;
using SmartAccountingAgent.TelegramBot;
using Telegram.Bot;

namespace SmartAccountingAgent.Extensions
{
    // ===================================================
    // تسجيل جميع الخدمات — أضف في Program.cs:
    //   builder.Services.AddSmartAccountingAgent(builder.Configuration);
    // ===================================================
    public static class DependencyInjection
    {
        public static IServiceCollection AddSmartAccountingAgent(
            this IServiceCollection services,
            IConfiguration config)
        {
            // ===== قاعدة البيانات =====
            var connSqlite    = config.GetConnectionString("SQLite");
            var connSqlServer = config.GetConnectionString("SqlServer");

            if (!string.IsNullOrEmpty(connSqlServer))
            {
                // SQL Server للشبكات
                services.AddDbContext<AccountingDbContext>(o =>
                    o.UseSqlServer(connSqlServer,
                        b => b.CommandTimeout(30)));
            }
            else
            {
                // SQLite افتراضياً (لا يحتاج إنترنت، خفيف جداً)
                services.AddDbContext<AccountingDbContext>(o =>
                    o.UseSqlite(connSqlite ?? "Data Source=SmartAccounting.db",
                        b => b.CommandTimeout(15)));
            }

            // ربط الواجهة بالتطبيق الفعلي
            services.AddScoped<IAccountingDb>(sp =>
                sp.GetRequiredService<AccountingDbContext>());

            // ===== المستودعات =====
            services.AddScoped<IProductRepository, ProductRepository>();
            services.AddScoped<IPartyRepository,   PartyRepository>();

            // ===== خدمات الأعمال =====
            services.AddScoped<AccountingEngine>();
            services.AddScoped<POSService>();
            services.AddScoped<ImagePreprocessor>();

            // ===== OCR: قراءة الفواتير =====
            services.Configure<InvoiceParserOptions>(config.GetSection("InvoiceParser"));
            services.AddHttpClient("AzureVision", c => {
                c.Timeout = TimeSpan.FromSeconds(30);
            });
            services.AddScoped<InvoiceParserService>();

            // ===== إدارة الجلسات (Singleton لأنها تعيش طوال عمر التطبيق) =====
            services.AddSingleton<SessionStore>();

            // ===== الوكيل الرئيسي =====
            services.AddScoped<AccountingAgent>();

            // ===== بوت تليجرام (اختياري) =====
            var telegramToken = config["Telegram:Token"];
            if (!string.IsNullOrWhiteSpace(telegramToken))
            {
                services.AddSingleton<ITelegramBotClient>(
                    new TelegramBotClient(telegramToken));

                services.AddSingleton(new TelegramBotConfig
                {
                    Token          = telegramToken,
                    WebhookUrl     = config["Telegram:WebhookUrl"],
                    AllowedChatIds = config.GetSection("Telegram:AllowedChatIds")
                                          .Get<List<long>>() ?? new List<long>()
                });

                services.AddSingleton<TelegramBotService>();
                services.AddHostedService(sp => sp.GetRequiredService<TelegramBotService>());
            }

            // ===== تحسينات الأداء =====
            // تجمع الاتصالات لتقليل استهلاك الذاكرة
            services.AddMemoryCache(o => o.SizeLimit = 500);

            return services;
        }

        // ===== تطبيق Migrations تلقائياً عند الإطلاق =====
        public static async Task ApplyMigrationsAsync(this IServiceProvider serviceProvider)
        {
            using var scope = serviceProvider.CreateScope();
            var db = scope.ServiceProvider.GetRequiredService<AccountingDbContext>();
            await db.Database.MigrateAsync();
        }
    }
}
