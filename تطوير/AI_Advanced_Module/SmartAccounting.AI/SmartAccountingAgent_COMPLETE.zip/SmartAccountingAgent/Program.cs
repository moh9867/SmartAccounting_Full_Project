using SmartAccountingAgent.Extensions;
using SmartAccountingAgent.TelegramBot;

var builder = WebApplication.CreateBuilder(args);

builder.WebHost.ConfigureKestrel(o => {
    o.Limits.MaxConcurrentConnections       = 50;
    o.Limits.MaxRequestBodySize             = 10 * 1024 * 1024;
    o.Limits.RequestHeadersTimeout          = TimeSpan.FromSeconds(15);
});

builder.Services.AddRazorPages();
builder.Services.AddServerSideBlazor(o => {
    o.DetailedErrors = builder.Environment.IsDevelopment();
    o.DisconnectedCircuitMaxRetained         = 5;
    o.DisconnectedCircuitRetentionPeriod     = TimeSpan.FromMinutes(3);
});

builder.Services.AddSmartAccountingAgent(builder.Configuration);

builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Logging.SetMinimumLevel(
    builder.Environment.IsDevelopment() ? LogLevel.Information : LogLevel.Warning);

var app = builder.Build();

await app.Services.ApplyMigrationsAsync();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseStaticFiles();
app.UseRouting();

var webhookPath = builder.Configuration["Telegram:WebhookPath"] ?? "/tg-hook";
if (!string.IsNullOrEmpty(builder.Configuration["Telegram:Token"]))
{
    app.MapPost(webhookPath, async (HttpContext ctx,
        TelegramBotService bot,
        Telegram.Bot.ITelegramBotClient client,
        CancellationToken ct) =>
        await TelegramWebhookEndpoint.Handle(ctx, client, bot, ct));
}

app.MapBlazorHub();
app.MapFallbackToPage("/_Host");

app.Run();
