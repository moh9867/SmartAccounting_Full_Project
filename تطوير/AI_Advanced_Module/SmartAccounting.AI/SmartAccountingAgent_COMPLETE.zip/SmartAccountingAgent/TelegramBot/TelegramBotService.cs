using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using SmartAccountingAgent.Agent.Core;
using SmartAccountingAgent.Models;
using Telegram.Bot;
using Telegram.Bot.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace SmartAccountingAgent.TelegramBot
{
    // ===================================================
    // بوت تليجرام المحاسبي - يعمل في الخلفية
    // Webhook بدلاً من Polling لتوفير الـ RAM
    // ===================================================
    public class TelegramBotService : BackgroundService
    {
        private readonly ITelegramBotClient _bot;
        private readonly AccountingAgent    _agent;
        private readonly SessionStore       _sessions;
        private readonly ILogger<TelegramBotService> _logger;
        private readonly TelegramBotConfig  _config;

        public TelegramBotService(
            ITelegramBotClient       bot,
            AccountingAgent          agent,
            SessionStore             sessions,
            TelegramBotConfig        config,
            ILogger<TelegramBotService> logger)
        {
            _bot      = bot;
            _agent    = agent;
            _sessions = sessions;
            _config   = config;
            _logger   = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("🤖 بوت تليجرام المحاسبي يعمل...");

            if (!string.IsNullOrEmpty(_config.WebhookUrl))
            {
                // ===== Webhook Mode (أفضل للإنتاج - لا يستهلك RAM) =====
                await _bot.SetWebhookAsync(
                    url:            _config.WebhookUrl,
                    allowedUpdates: new[] { UpdateType.Message, UpdateType.CallbackQuery },
                    cancellationToken: stoppingToken);
                _logger.LogInformation("✅ Webhook مُفعّل: {Url}", _config.WebhookUrl);

                // انتظر حتى يتم الإلغاء
                await Task.Delay(Timeout.Infinite, stoppingToken);
            }
            else
            {
                // ===== Long Polling Mode (للتطوير المحلي) =====
                var receiverOptions = new ReceiverOptions
                {
                    AllowedUpdates = new[] { UpdateType.Message, UpdateType.CallbackQuery },
                    ThrowPendingUpdates = true
                };

                _bot.StartReceiving(
                    updateHandler:      HandleUpdateAsync,
                    pollingErrorHandler: HandleErrorAsync,
                    receiverOptions:    receiverOptions,
                    cancellationToken:  stoppingToken);

                await Task.Delay(Timeout.Infinite, stoppingToken);
            }
        }

        // ===================================================
        // معالج الرسائل الواردة
        // ===================================================
        public async Task HandleUpdateAsync(ITelegramBotClient bot, Update update, CancellationToken ct)
        {
            try
            {
                if (update.Type == UpdateType.CallbackQuery && update.CallbackQuery != null)
                {
                    await HandleCallbackAsync(update.CallbackQuery, ct);
                    return;
                }

                if (update.Message == null) return;
                var msg    = update.Message;
                var chatId = msg.Chat.Id;

                // التحقق من التفويض
                if (!IsAuthorized(chatId))
                {
                    await bot.SendTextMessageAsync(chatId, "⛔ غير مصرح لك باستخدام هذا البوت.", cancellationToken: ct);
                    return;
                }

                // ===== صورة فاتورة =====
                if (msg.Type == MessageType.Photo && msg.Photo != null)
                {
                    await HandlePhotoAsync(msg, chatId, ct);
                    return;
                }

                // ===== أمر /start =====
                if (msg.Text?.StartsWith("/start") == true)
                {
                    await SendWelcomeAsync(chatId, msg.From?.FirstName ?? "مستخدم", ct);
                    return;
                }

                // ===== رسالة نصية =====
                if (!string.IsNullOrEmpty(msg.Text))
                {
                    await HandleTextMessageAsync(msg.Text, chatId, ct);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "خطأ في معالجة رسالة تليجرام");
            }
        }

        // ===================================================
        // معالج الرسائل النصية
        // ===================================================
        private async Task HandleTextMessageAsync(string text, long chatId, CancellationToken ct)
        {
            // إظهار "يكتب..." أثناء المعالجة
            await _bot.SendChatActionAsync(chatId, ChatAction.Typing, cancellationToken: ct);

            // البحث عن جلسة موجودة أو إنشاء جديدة
            var session = _sessions.GetByTelegram(chatId);
            var sessionId = session?.SessionId ?? chatId.ToString();

            var request = new AgentRequest
            {
                SessionId      = sessionId,
                UserMessage    = text,
                Channel        = "telegram",
                TelegramChatId = chatId
            };

            var response = await _agent.ProcessAsync(request);

            // إرسال الرد مع أزرار الاختيار السريع
            await SendResponseAsync(chatId, response, ct);
        }

        // ===================================================
        // معالج صور الفواتير
        // ===================================================
        private async Task HandlePhotoAsync(Message msg, long chatId, CancellationToken ct)
        {
            await _bot.SendChatActionAsync(chatId, ChatAction.Typing, cancellationToken: ct);
            await _bot.SendTextMessageAsync(chatId, "📷 جاري قراءة الفاتورة...", cancellationToken: ct);

            try
            {
                // تحميل أكبر نسخة من الصورة
                var photo  = msg.Photo!.Last();
                var file   = await _bot.GetFileAsync(photo.FileId, cancellationToken: ct);
                var stream = new System.IO.MemoryStream();
                await _bot.DownloadFileAsync(file.FilePath!, stream, cancellationToken: ct);
                var base64 = Convert.ToBase64String(stream.ToArray());

                var request = new AgentRequest
                {
                    SessionId      = chatId.ToString(),
                    UserMessage    = "صورة فاتورة",
                    Channel        = "telegram",
                    TelegramChatId = chatId,
                    ImageBase64    = base64
                };

                var response = await _agent.ProcessAsync(request);
                await SendResponseAsync(chatId, response, ct);
            }
            catch (Exception ex)
            {
                await _bot.SendTextMessageAsync(chatId,
                    $"❌ تعذّر قراءة الصورة: {ex.Message}", cancellationToken: ct);
            }
        }

        // ===================================================
        // معالج أزرار Inline
        // ===================================================
        private async Task HandleCallbackAsync(CallbackQuery callback, CancellationToken ct)
        {
            await _bot.AnswerCallbackQueryAsync(callback.Id, cancellationToken: ct);

            if (callback.Data == null) return;

            await HandleTextMessageAsync(callback.Data, callback.Message!.Chat.Id, ct);
        }

        // ===================================================
        // إرسال الرد مع التنسيق والأزرار
        // ===================================================
        private async Task SendResponseAsync(long chatId, AgentResponse response, CancellationToken ct)
        {
            IReplyMarkup? markup = null;

            // بناء أزرار الاختيار السريع
            if (response.QuickReplies.Any())
            {
                var rows = response.QuickReplies
                    .Chunk(2) // صفان من الأزرار
                    .Select(row => row.Select(qr =>
                        InlineKeyboardButton.WithCallbackData(qr.Label, qr.Value)).ToArray())
                    .ToArray();
                markup = new InlineKeyboardMarkup(rows);
            }

            // تقسيم الرسائل الطويلة (حد تليجرام 4096 حرف)
            var text = response.Message;
            if (text.Length <= 4000)
            {
                await _bot.SendTextMessageAsync(
                    chatId:             chatId,
                    text:               text,
                    parseMode:          ParseMode.Markdown,
                    replyMarkup:        markup,
                    cancellationToken:  ct);
            }
            else
            {
                // إرسال على جزئين
                await _bot.SendTextMessageAsync(chatId, text[..4000], parseMode: ParseMode.Markdown, cancellationToken: ct);
                await _bot.SendTextMessageAsync(chatId, text[4000..], parseMode: ParseMode.Markdown, replyMarkup: markup, cancellationToken: ct);
            }
        }

        // ===================================================
        // رسالة الترحيب
        // ===================================================
        private async Task SendWelcomeAsync(long chatId, string name, CancellationToken ct)
        {
            var keyboard = new InlineKeyboardMarkup(new[]
            {
                new[] { InlineKeyboardButton.WithCallbackData("📋 فاتورة بيع",     "فاتورة بيع"),
                        InlineKeyboardButton.WithCallbackData("📦 فاتورة شراء",   "فاتورة شراء") },
                new[] { InlineKeyboardButton.WithCallbackData("🏪 POS كاشير",      "pos"),
                        InlineKeyboardButton.WithCallbackData("📊 ملخص اليوم",    "ملخص اليوم") },
                new[] { InlineKeyboardButton.WithCallbackData("👤 عميل جديد",      "عميل جديد"),
                        InlineKeyboardButton.WithCallbackData("🏭 مورد جديد",      "مورد جديد") },
                new[] { InlineKeyboardButton.WithCallbackData("⚠️ مخزون منخفض",  "مخزون منخفض"),
                        InlineKeyboardButton.WithCallbackData("💡 مساعدة",         "مساعدة") },
            });

            await _bot.SendTextMessageAsync(chatId,
                $"👋 أهلاً {name}!\n\n" +
                "أنا **الوكيل المحاسبي الذكي** لـ Smart Accounting\n\n" +
                "يمكنني مساعدتك في:\n" +
                "✅ تسجيل فواتير البيع والشراء\n" +
                "✅ نقطة البيع المباشر (POS)\n" +
                "✅ إضافة عملاء وموردين\n" +
                "✅ قراءة الفواتير من صور 📷\n" +
                "✅ التقارير والإحصائيات\n\n" +
                "اختر أو اكتب ما تريد:",
                parseMode:    ParseMode.Markdown,
                replyMarkup:  keyboard,
                cancellationToken: ct);
        }

        private bool IsAuthorized(long chatId)
        {
            if (!_config.AllowedChatIds.Any()) return true; // مفتوح للجميع
            return _config.AllowedChatIds.Contains(chatId);
        }

        private Task HandleErrorAsync(ITelegramBotClient bot, Exception ex, CancellationToken ct)
        {
            _logger.LogError(ex, "خطأ في بوت تليجرام");
            return Task.CompletedTask;
        }
    }

    // ===================================================
    // Webhook Controller - لاستقبال Updates من تليجرام
    // ===================================================
    // في Program.cs أضف: app.MapPost("/telegram-webhook", TelegramWebhookEndpoint.Handle);
    public static class TelegramWebhookEndpoint
    {
        public static async Task Handle(
            HttpContext context,
            ITelegramBotClient bot,
            TelegramBotService botService,
            CancellationToken ct)
        {
            var update = await System.Text.Json.JsonSerializer
                .DeserializeAsync<Update>(context.Request.Body, cancellationToken: ct);

            if (update != null)
                await botService.HandleUpdateAsync(bot, update, ct);

            context.Response.StatusCode = 200;
        }
    }

    // ===== إعدادات البوت =====
    public class TelegramBotConfig
    {
        public string       Token         { get; set; } = string.Empty;
        public string?      WebhookUrl    { get; set; } // فارغ = Long Polling
        public List<long>   AllowedChatIds { get; set; } = new(); // فارغ = الجميع
    }
}
